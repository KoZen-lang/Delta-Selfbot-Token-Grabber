# DeltaSelf
 Le delta self deobfusqué et sans grabber, enfin j'espere avoir tout retiré O-O
